require('babel/register');
module.exports = require('./other/webpack.config.es6');
