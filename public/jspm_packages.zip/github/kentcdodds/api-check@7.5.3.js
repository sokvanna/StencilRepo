define(["github:kentcdodds/api-check@7.5.3/dist/api-check"], function(main) {
  return main;
});