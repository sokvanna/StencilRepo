require('./checkers.test');
require('./api-check-util.test');
require('./api-check.test');
require('./bugs.test');
require('./prs-plz.test');
