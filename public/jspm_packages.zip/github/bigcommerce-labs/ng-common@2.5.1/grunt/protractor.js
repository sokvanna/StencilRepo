module.exports = function(grunt) {
    return {
        options: {
            keepAlive: false,
            configFile: 'grunt/protractor.conf.js'
        },
        deploy: {
            options: {
                args: {
                    specs: ['src/app/**/*.scenario.js'],
                    seleniumServerJar: '<%= seleniumServerJar %>',
                    chromeDriver: '<%= chromeDriver %>',
                    baseUrl: 'http://localhost:<%= serverPort %>'
                }
            }
        }
    }
};
