module.exports = function(grunt) {
    require('time-grunt')(grunt);
    require('load-grunt-config')(grunt, {
        jitGrunt: {
            nggettext_extract: 'grunt-angular-gettext',
            nggettext_compile: 'grunt-angular-gettext',
            protractor: 'grunt-protractor-runner'
        },
        data: {
            bcAppDirectory: process.env.BC_APP_DIR || '../bigcommerce',
            seleniumServerJar: process.env.SELENIUM_SERVER_JAR || '/usr/local/lib/node_modules/protractor/selenium/selenium-server-standalone-2.42.2.jar',
            chromeDriver: process.env.CHROME_DRIVER || '/usr/local/lib/node_modules/protractor/selenium/chromedriver',
            devAssetPath: '/vendor/bower_components/<%= package.name %>/build',
            prodAssetPath: '/bower/<%= package.name %>/dist',
            serverPort: 8888,
            karmaVendors: [
                "bower_components/lodash/dist/lodash.js",
                "bower_components/pubsub-js/src/pubsub.js",
                "bower_components/angular/angular.js",
                "bower_components/angular-mocks/angular-mocks.js",
                "bower_components/angular-sanitize/angular-sanitize.js",
                "bower_components/angular-animate/angular-animate.js",
                "bower_components/angular-gettext/dist/angular-gettext.js",
                "bower_components/angular-cache/dist/angular-cache.js",
                "bower_components/angular-bootstrap/ui-bootstrap-tpls.js"
            ]
        }
    });
};
