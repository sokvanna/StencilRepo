angular.module('ng-common.address.address-utils-factory', [])
    .factory('addressUtils', function addressUtilsFactory() {
      var service = {
            prettify: prettify
          };

      /**
       *
       * @param {Object} address The address to be formatted
       * @param {string} [address.first_name]
       * @param {string} [address.last_name]
       * @param {string} [address.address_1]
       * @param {string} [address.address_2]
       * @param {string} [address.city]
       * @param {string} [address.state]
       * @param {string} [address.post_code]
       * @param {string} [address.country_name]
       * @param {string} [lineSeparator]
       * @returns {string} The formatted address
       */
      function prettify (address, lineSeparator) {
        var prettyAddress = '';
        lineSeparator = lineSeparator || '<br>';
        if (address.first_name) {
          prettyAddress += address.first_name;
        }
        if (address.last_name) {
          if (prettyAddress) {
            prettyAddress += ' ';
          }
          prettyAddress += address.last_name;
        }
        if (address.address_1) {
          if (prettyAddress) {
            prettyAddress += lineSeparator;
          }
          prettyAddress += address.address_1;
        }
        if (address.address_2) {
          if (prettyAddress) {
            prettyAddress += lineSeparator;
          }
          prettyAddress += address.address_2;
        }

        if ((address.city || address.state || address.post_code) && prettyAddress) {
          prettyAddress += lineSeparator;
        }

        if (address.city) {
          prettyAddress += address.city;
        }

        if (address.state) {
          if (address.city) {
            prettyAddress += ', ';
          }
          prettyAddress += address.state;
        }

        if (address.post_code) {
          if (address.city || address.state) {
            prettyAddress += ' ';
          }
          prettyAddress += address.post_code;
        }

        if (address.country_name) {
          if (prettyAddress) {
            prettyAddress += lineSeparator;
          }
          prettyAddress += address.country_name;
        }

        return prettyAddress;
      }

      return service;
    });
