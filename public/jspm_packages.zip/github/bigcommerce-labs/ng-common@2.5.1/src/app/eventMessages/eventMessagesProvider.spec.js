describe('eventMessages', function() {
    var eventMessagesProvider,
        eventMessagesService,
        mockMessage = {
            testData: 'hello'
        },
        mockNamespace = 'testNamespace',
        mockTargetOrigin = 'mockTargetOrigin',
        mockWindow = {
            postMessage: angular.noop
        };

    beforeEach(function() {
        angular.module('ng-common.bc-app', [])
            .constant('BC_APP_CONFIG', {});
    });

    beforeEach(module('ng-common.event-messages.provider'));

    beforeEach(module(function(_eventMessagesProvider_) {
        eventMessagesProvider = _eventMessagesProvider_;
    }));

    beforeEach(inject(function($injector) {
        eventMessagesService = $injector.get('eventMessages');
    }));

    beforeEach(function() {
        eventMessagesProvider.setOtherWindow(mockWindow);
        eventMessagesProvider.setNamespace(mockNamespace);
        eventMessagesProvider.setTargetOrigin(mockTargetOrigin);
    });

    describe('provider method', function() {
        it('setOtherWindow should set provider.otherWindow', function() {
            expect(eventMessagesProvider.otherWindow).toBe(mockWindow);
        });

        it('setNamespace should set provider.namespace', function() {
            expect(eventMessagesProvider.namespace).toEqual(mockNamespace);
        });

        it('setTargetOrigin should set provider.targetOrigin', function() {
            expect(eventMessagesProvider.targetOrigin).toEqual(mockTargetOrigin);
        });

        it('sendPostMessage should call postMessage on the specified otherWindow ', function() {
            spyOn(mockWindow, 'postMessage');

            eventMessagesProvider.sendPostMessage(mockMessage);

            expect(eventMessagesProvider.otherWindow.postMessage).toHaveBeenCalledWith(mockNamespace + ':' + angular.toJson(mockMessage), mockTargetOrigin);
        });
    });

    describe('service', function() {
        describe('postMessage method', function() {
            beforeEach(function() {
                spyOn(eventMessagesProvider, 'sendPostMessage');
            });

            it('should register a subscription if a callback is provided', function() {
                eventMessagesService.postMessage('test', mockMessage, angular.noop);

                expect(eventMessagesProvider.sendPostMessage).toHaveBeenCalled();
                expect(eventMessagesProvider.subscriptions.length).toBe(1);
            });

            it('should not register a subscription if no callback is provided', function() {
                eventMessagesService.postMessage('test', mockMessage);

                expect(eventMessagesProvider.sendPostMessage).toHaveBeenCalled();
                expect(eventMessagesProvider.subscriptions.length).toBe(0);
            });
        });

        describe('subscribe method', function() {
            it('should register a subscription when called', function() {
                eventMessagesService.subscribe('test', angular.noop);

                expect(eventMessagesProvider.subscriptions.length).toBe(1);
            });

            it('should register a subscription that is called when the provided event is fired', inject(function($window) {
                var testCallback = jasmine.createSpy('testCallback'),
                    testEvent = $window.document.createEvent('Event');

                testEvent.initEvent('message', true, true);
                testEvent.data = mockNamespace + ':' + angular.toJson({
                    name: 'test',
                    data: mockMessage
                });

                eventMessagesService.subscribe('test', testCallback);

                $window.dispatchEvent(testEvent);

                expect(testCallback).toHaveBeenCalledWith(mockMessage);
            }));
        });
    });
});
