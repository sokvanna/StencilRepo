angular.module('ng-common.flash-messages', [
    'ng-common.flash-messages.service',
    'ng-common.flash-messages.directive'
]);
