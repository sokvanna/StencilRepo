describe('interapp', function() {
    beforeEach(function() {
        browser.get('/examples/interapp/index.html');
    });

    it('should send message to app2', function() {
        element(by.model('App1Ctrl.message')).sendKeys('hi!');
        element(by.css('#send-message')).click();

        element(by.model('App1Ctrl.message')).sendKeys('hey :)');
        element(by.css('#send-message')).click();

        expect(element.all(by.css('ul#messages li')).count()).toBe(2);
    });

    it('should unpublish and not receive anymore messages', function() {
        element(by.model('App1Ctrl.message')).sendKeys('hi!');
        element(by.css('#send-message')).click();

        element(by.css('#unsubscribe')).click();

        element(by.model('App1Ctrl.message')).sendKeys('hey :)');
        element(by.css('#send-message')).click();

        expect(element.all(by.css('ul#messages li')).count()).toBe(1);
    });
});
