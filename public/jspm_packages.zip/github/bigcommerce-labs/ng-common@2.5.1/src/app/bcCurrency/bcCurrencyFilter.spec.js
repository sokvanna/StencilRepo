describe('Filter: bcCurrency', function() {
    var $filter;

    beforeEach(module('ng-common.bc-currency.filter'));

    beforeEach(module(function($provide) {
        $provide.value('bcCurrency', {
            currencyPosition: 'left',
            currencySymbol: '$'
        });
    }));

    beforeEach(inject(function(_$filter_) {
        $filter = _$filter_;
    }));

    it('should return a properly formatted string with pre-configured settings', function() {
        expect($filter('bcCurrency')('1000')).toEqual('$1,000.00');
    });

    it('should return a properly formatted string with overridden settings', function() {
        expect($filter('bcCurrency')('1000', '$', 'right')).toEqual('1,000.00$');
    });
});
