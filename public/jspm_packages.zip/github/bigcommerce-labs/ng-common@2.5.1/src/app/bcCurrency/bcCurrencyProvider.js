angular.module('ng-common.bc-currency.provider', [])
    .provider('bcCurrency', function bcCurrencyProvider() {
        var currencyPosition,
            currencySymbol;

        this.setCurrencyPosition = function setCurrencyPosition(position) {
            currencyPosition = position;
        };

        this.setCurrencySymbol = function setCurrencySymbol(symbol) {
            currencySymbol = symbol;
        };

        this.$get = function bcCurrencyProvider() {
            return {
                currencyPosition: currencyPosition,
                currencySymbol: currencySymbol
            };
        };
    });