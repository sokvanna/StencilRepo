describe('transformFormDataRequest service tests', function () {
    var mockHeaders,
        transformFormDataRequest;

    function getHeaderMock() {
        return mockHeaders;
    }

    beforeEach(module('ng-common.transformformdatarequest.service'));

    beforeEach(inject(function ($injector) {
        transformFormDataRequest = $injector.get('transformFormDataRequest');
        mockHeaders = {
            'Content-Type': 'appliction-x-invalid-content'
        };
    }));

    describe('transformFormDataRequest function', function () {
        it('should return URL encoded data', function () {
            expect(transformFormDataRequest({
                'filling': 'blackberry',
                'crust': 'flaky butter',
                'serve_heated': true
            }, getHeaderMock)).toBe("filling=blackberry&crust=flaky%20butter&serve_heated=true");
        });

        it('should alter the headers to reflect the data type', function () {
            transformFormDataRequest({}, getHeaderMock);
            expect(mockHeaders['Content-Type']).toBe('application/x-www-form-urlencoded');
        });

        it('should encode arrays into PHP-compatible array parameters', function() {
            expect(transformFormDataRequest({
                'crustIngredients': ['flour', 'water', 'butter', 'salt', 'sugar']
            }, getHeaderMock)).toBe("crustIngredients[]=flour&crustIngredients[]=water&crustIngredients[]=butter&crustIngredients[]=salt&crustIngredients[]=sugar");
        });
    });
});
