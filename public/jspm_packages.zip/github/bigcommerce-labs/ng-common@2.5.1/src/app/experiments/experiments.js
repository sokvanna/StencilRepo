angular.module('ng-common.experiments', [
    'ng-common.experiments.provider',
]);
