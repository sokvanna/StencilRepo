describe('Filter: cdnPath', function() {
    var $filter,
        $window,
        cdnPath = 'https://my-cdn';

    beforeEach(function() {
        angular.module('ng-common.bc-app', [])
            .constant('BC_APP_CONFIG', {
                cdnPath: cdnPath
            });
    });

    beforeEach(module('ng-common.cdn-path.filter'));

    beforeEach(inject(function(_$filter_, _$window_) {
        $filter = _$filter_;
        $window = _$window_;
    }));

    it('should set the correct cdnPath to an asset', function() {
        var assetPath = '/img/my-awesome-img.jpg';

        expect($filter('cdnPath')(assetPath)).toEqual(cdnPath + assetPath);
    });
});
