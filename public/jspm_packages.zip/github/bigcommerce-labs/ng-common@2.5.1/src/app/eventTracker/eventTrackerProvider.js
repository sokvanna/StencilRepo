angular.module('ng-common.event-tracker.provider', ['ng-common.lodash'])
    .provider('eventTracker', function eventTrackerProvider(_) {
        var thirdPartyTrackerService,
            defaultTrackerOptions = {};

        this.setThirdPartyTrackerService = function(ts) {
            thirdPartyTrackerService = ts;
        };

        this.setDefaultTrackerOptions = function(dto) {
            defaultTrackerOptions = dto;
        };

        this.$get = function() {
            if (! thirdPartyTrackerService) {
                throw new Error('Third party tracker service not set.');
            }

            if (typeof thirdPartyTrackerService.track !== 'function') {
                throw new Error('Third party tracker service does not have the track method.');
            }

            return {
                track: function(name, properties, options, callback) {
                    if (! name) {
                        throw new Error('A name is required to track an event.');
                    }

                    properties = properties || {};
                    options = _.assign({}, defaultTrackerOptions, options);
                    callback = callback || angular.noop;

                    try {
                        thirdPartyTrackerService.track.call(thirdPartyTrackerService, name, properties, options, callback);
                    } catch (e) {
                        // Failing silently as the third party tracker service has failed up and we don't
                        // want our application failing as well.
                    }
                }
            };
        };
    });
