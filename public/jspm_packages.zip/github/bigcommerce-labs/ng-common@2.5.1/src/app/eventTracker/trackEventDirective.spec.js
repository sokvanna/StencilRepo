describe('Directive: trackEvent', function () {
    var $compile,
        $scope,
        trackMethod = jasmine.createSpy('Tracker Method');

    beforeEach(function() {
        function Tracker() {
            this.track = trackMethod;
        }
        angular.module('ng-common.bc-app', [])
            .constant('BC_APP_CONFIG', {
                eventTrackerService: new Tracker()
            });
    });

    beforeEach(module('ng-common.event-tracker.directive'));

    beforeEach(module('ng-common.bc-app'));

    beforeEach(module(function(eventTrackerProvider, BC_APP_CONFIG) {
        eventTrackerProvider.setThirdPartyTrackerService(BC_APP_CONFIG.eventTrackerService);
    }));

    beforeEach(inject(function(_$compile_, $rootScope) {
        $compile = _$compile_;
        $scope = $rootScope.$new();
    }));

    describe('fire off track event', function() {
        it('should fire off track event when clicked with declarative params', function() {
            var element = $compile('<a ' +
                'track-event="My Event"' +
                'track-event-properties="{foo: \'bar\'}"' +
                'track-event-options="{bar: \'foo\'}">A Link</a>')($scope);

            element.triggerHandler('click');

            expect(trackMethod).toHaveBeenCalledWith('My Event', {foo: 'bar'}, {bar: 'foo'}, jasmine.any(Function));
        });

        it('should fire off track event when clicked with $scope params', function() {
            $scope.name = 'My Event';
            $scope.eventProperties = {foo: 'bar'};
            $scope.eventOptions = {bar: 'foo'};
            $scope.eventCallback = angular.noop;
            var element = $compile('<a ' +
                'track-event="{{name}}"' +
                'track-event-properties="{{eventProperties}}"' +
                'track-event-options="{{eventOptions}}"' +
                'track-event-callback="eventCallback(data)">A Link</a>')($scope);

            element.triggerHandler('click');

            expect(trackMethod).toHaveBeenCalledWith($scope.name, $scope.eventProperties, $scope.eventOptions, jasmine.any(Function));
        });

        it('should fire off track event on specified event', function() {
            var on = 'change',
                element = $compile('<select ' +
                    'track-event="My Event"' +
                    'track-event-on="' + on + '"></select>')($scope);

            element.triggerHandler(on);
            expect(trackMethod).toHaveBeenCalled();
        });
    });
});
