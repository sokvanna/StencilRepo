describe('http-once', function() {
    var key = 'arbitrary',
        url = '/admin/test',
        urlAlt = '/admin/test2',
        $http,
        $httpBackend,
        $q,
        $rootScope,
        httpOnce;

    beforeEach(module('ng-common.http-once'));

    beforeEach(inject(function($injector) {
        $http = $injector.get('$http');
        $httpBackend = $injector.get('$httpBackend');
        $q = $injector.get('$q');
        $rootScope = $injector.get('$rootScope');
        httpOnce = $injector.get('httpOnce');
    }));

    describe('decorator', function() {
        var cancelledCallback,
            overridingCallback;

        beforeEach(function() {
            cancelledCallback = jasmine.createSpy('cancelledCallback');
            overridingCallback = jasmine.createSpy('overridingCallback');

            $httpBackend.expectGET(url).respond(200);
            $httpBackend.expectGET(urlAlt).respond(200);
        });

        it('should not affect requests if the "once" option is not defined', function() {
            $http.get(url).then(cancelledCallback);
            $http.get(urlAlt).then(overridingCallback);

            $rootScope.$digest();
            $httpBackend.flush();

            expect(cancelledCallback).toHaveBeenCalled();
            expect(overridingCallback).toHaveBeenCalled();
        });

        it('should cancel the previous request if the "once" option is defined for its key', function() {
            $http.get(url, { once: key }).then(cancelledCallback);
            $http.get(urlAlt, { once: key }).then(overridingCallback);

            $rootScope.$digest();
            $httpBackend.flush();

            expect(cancelledCallback).not.toHaveBeenCalled();
            expect(overridingCallback).toHaveBeenCalled();
        });

        afterEach(function () {
            $httpBackend.verifyNoOutstandingRequest();
        });
    });

    describe('service', function() {
        beforeEach(function() {
            httpOnce.create(key);
        });

        it('should return correct boolean for check()', function() {
            expect(httpOnce.check(key)).toBeTruthy();
        });

        it('should return correct data and remove it from stack when using pluck()', function() {
            expect(httpOnce.check(key)).toBeTruthy();
            expect(httpOnce.cancel(key)).toBeTruthy();
            expect(httpOnce.check(key)).toBeFalsy();
        });
    });
});
