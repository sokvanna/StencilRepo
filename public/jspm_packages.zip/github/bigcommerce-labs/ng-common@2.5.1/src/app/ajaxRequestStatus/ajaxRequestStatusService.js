angular.module('ng-common.ajax-request-status.service', [])

    .factory('ajaxRequestStatus', function($q, $rootScope) {
        var ajaxCount = 0,
            service = {
                request: ajaxRequest,
                requestError: ajaxRequestError,
                response: ajaxResponse,
                responseError: ajaxResponseError
            };

        function ajaxRequest(config) {
            emitTrue();

            return config;
        }

        function ajaxRequestError(rejection) {
            emitFalse();

            return $q.reject(rejection);
        }

        function ajaxResponse(response) {
            emitFalse();

            return response;
        }

        function ajaxResponseError(rejection) {
            emitFalse();

            return $q.reject(rejection);
        }

        function emitFalse() {
            ajaxCount -= 1;

            if (ajaxCount === 0) {
                $rootScope.$emit('ajaxRequestRunning', false);
            }
        }

        function emitTrue() {
            if (ajaxCount === 0) {
                $rootScope.$emit('ajaxRequestRunning', true);
            }

            ajaxCount += 1;
        }

        return service;
    });
