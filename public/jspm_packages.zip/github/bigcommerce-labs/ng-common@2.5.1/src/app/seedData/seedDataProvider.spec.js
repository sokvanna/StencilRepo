describe('Provider: seedData', function() {

    var seedData,
        keys = {
            'foo': {}
        };

    beforeEach(module('ng-common.seed-data.provider'));

    beforeEach(module(function(seedDataProvider) {
        _.forOwn(keys, function(data, key) {
            seedDataProvider.put(key, data);
        });
    }));

    beforeEach(inject(function(_seedData_) {
        seedData = _seedData_;
    }));

    it('should return correct boolean for check()', function() {
        expect(seedData.check('foo')).toBeTruthy();
        expect(seedData.check('/does-not-exist')).toBeFalsy();
    });

    it('should return correct data and remove it from stack when using pluck()', function() {
        expect(seedData.check('foo')).toBeTruthy();
        expect(seedData.pluck('foo')).toBe(keys['foo']);
        expect(seedData.check('foo')).toBeFalsy();
    });
});
