angular.module('ng-common.seed-data.http-decorator', ['ng-common.seed-data.provider', 'ng-common.lodash'])
    .config(function($provide, _) {
        $provide.decorator('$http', function seedDataHttpDecorator($delegate, $injector) {
            var $q = $injector.get('$q'),
                $cacheFactory = $injector.get('$cacheFactory'),
                seedData = $injector.get('seedData');

            $delegate._get = $delegate.get;

            $delegate.get = function seedDataHttpGet(url, config) {
                config = config || {};

                if (! seedData.check(config.seededDataKey)) {
                    return $delegate._get(url, config);
                }

                var data = seedData.pluck(config.seededDataKey),
                    status = 200,
                    headers = {},
                    statusText = 'OK',
                    promise = $q.when({
                        data: data,
                        status: status,
                        headers: headers,
                        config: config,
                        statusText: statusText
                    });

                if ((config.cache || $delegate.defaults.cache) && config.cache !== false) {
                    var cache = _.isObject(config.cache) ? config.cache
                        : _.isObject($delegate.defaults.cache) ? $delegate.defaults.cache
                        : $cacheFactory.get('$http');

                    cache.put(buildUrl(url, config.params), [status, data, headers, statusText]);
                }

                promise.success = function(fn) {
                    promise.then(function(response) {
                        fn(response.data, response.status, response.headers, config);
                    });

                    return promise;
                };

                promise.error = angular.noop;

                return promise;
            };

            return $delegate;
        });

        // This function is copied from AngularJS source code
        function encodeUriQuery(val, pctEncodeSpaces) {
            return encodeURIComponent(val).
                replace(/%40/gi, '@').
                replace(/%3A/gi, ':').
                replace(/%24/g, '$').
                replace(/%2C/gi, ',').
                replace(/%20/g, (pctEncodeSpaces ? '%20' : '+'));
        }

        // This function is copied from AngularJS source code
        function forEachSorted(obj, iterator, context) {
            var keys = _.keys(obj).sort();
            for (var i = 0; i < keys.length; i++) {
                iterator.call(context, obj[keys[i]], keys[i]);
            }

            return keys;
        }

        // This function is copied from AngularJS source code
        function buildUrl(url, params) {
            if (! params) {
                return url;
            }

            var parts = [];
            forEachSorted(params, function(value, key) {
                if (value === null || _.isUndefined(value)) {
                    return;
                }
                if (! _.isArray(value)) {
                    value = [value];
                }

                _.forEach(value, function(v) {
                    if (_.isObject(v)) {
                        v = JSON.stringify(v);
                    }
                    parts.push(encodeUriQuery(key) + '=' +
                        encodeUriQuery(v));
                });
            });

            if (parts.length > 0) {
                url += ((url.indexOf('?') == - 1) ? '?' : '&') + parts.join('&');
            }

            return url;
        }
    });
