// modded from https://gist.github.com/johnyanarella/5293749
// these utility functions allow easy manipulation of the query string
lodashModern.mixin({
    // @param parameters: the object to be endcoded to the query string
    toQueryString: function toQueryString (parameters) {
        var queryString = lodashModern.reduce(parameters,
                function (components, value, key) {
                    components.push(key + '=' + encodeURIComponent(value));
                    return components;
                }, []).join('&');

        if (queryString.length) {
            queryString = '?' + queryString;
        }
        return queryString;
    },

    // @param queryString: the queryString to be parsed to JSON
    // can be retrieved easily with window.location.search
    fromQueryString: function fromQueryString (queryString) {
        return lodashModern.reduce(queryString.replace('?', '').split('&'),
            function (parameters, parameter) {
                if (parameter.length) {
                    lodashModern.extend(parameters, lodashModern.object([lodashModern.map(parameter.split('='), decodeURIComponent)]));
                }
                return parameters;
            }, {});
    }
});
