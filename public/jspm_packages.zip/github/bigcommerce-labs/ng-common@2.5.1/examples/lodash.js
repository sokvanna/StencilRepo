// Create a query string from object/JSON
lodashModern.toQueryString({foo: 'bar', faz: 'baz'}) // "?foo=bar&faz=baz"

// Parse query string to JSON
lodashModern.fromQueryString('?foo=bar&faz=baz') // {foo: 'bar', faz: 'baz'}
