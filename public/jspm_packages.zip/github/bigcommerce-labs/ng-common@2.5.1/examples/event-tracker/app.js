function Tracker() {
    this.track = function(name, properties, options, callback) {
        console.log('name:', name);
        console.log('properties:', properties);
        console.log('options:', options);
        callback.call();

        this.anotherFunction();
    };

    this.anotherFunction = function() {
        console.log('Other function called!');
    }
}

angular.module('ng-common.bc-app', [])
    .constant('BC_APP_CONFIG', {
        eventTrackerService: new Tracker()
    });

angular.module('app', ['ng-common.event-tracker'])
    .controller('AppCtrl', function($scope, $log, eventTracker) {
        var Ctrl = this;

        Ctrl.eventName = 'Foo Event';
        Ctrl.eventData = {foo: 'bar'};
        Ctrl.eventOptions = {bar: 'foo'};
        Ctrl.eventCallback = function() {
            $log.log('Callback Ran!');
        };

        Ctrl.triggerEvent = function() {
            eventTracker.track('My Controller Event', {some: 'things'}, null, function() {
                $log.log('console log worked');
            })
        };
    });
