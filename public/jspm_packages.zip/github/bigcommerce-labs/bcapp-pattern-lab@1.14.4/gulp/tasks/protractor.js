/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    protractor = require('gulp-protractor').protractor,
    connect = require('gulp-connect');

function e2eTests() {
    gulp.src(config.js.src + '/**/*.scenario.js')
        .pipe(protractor({
            configFile: './gulp/tasks/protractor.conf.js',
            args: [
                '--seleniumServerJar=' + config.seleniumServerJar,
                '--chromeDriver=' + config.chromeDriver,
                '--baseUrl=http://localhost:' + config.serverPort
            ]
        }))
        .on('end', function() {
            connect.serverClose();
        })
        .on('error', function() {
            connect.serverClose();
        });
}

gulp.task('e2e', ['build', 'connect'], e2eTests);

