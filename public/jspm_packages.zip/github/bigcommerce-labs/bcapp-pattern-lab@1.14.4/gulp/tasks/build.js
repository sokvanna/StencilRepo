/* */ 
"format global";
var gulp = require('gulp'),
    runSequence = require('run-sequence');

gulp.task('build', function(callback) {
    runSequence(
        'clean:build',
        'sprites',
        'icons',
        'svg',
        'images',
        [
            'styles',
            'websiteStyles',
            'karma:bcappPatternLab',
            'karma:website',
            'templates'
        ],
        callback
    );
});
