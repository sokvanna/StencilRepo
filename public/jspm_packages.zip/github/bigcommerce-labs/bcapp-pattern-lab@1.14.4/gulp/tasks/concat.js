/* */ 
"format global";
var gulp = require('gulp'),
    concat = require('gulp-concat'),
    babel = require('gulp-babel'),
    sourcemaps = require('gulp-sourcemaps'),
    browserSync = require('browser-sync'),
    reload = browserSync.reload,
    config = require('../config');

function concatBcappPatternLabComponents() {
    var stream = gulp.src([
            config.js.src + '/**/*.js',
            '!' + config.js.src + '/**/*.scenario.js',
            '!' + config.js.src + '/**/*.spec.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(babel())
        .pipe(concat('bcapp-pattern-lab-components.js'))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(config.js.build + '/bcapp'))
        .pipe(reload({stream:true}));

    return stream;
}

function concatBcappPatternLabDeps() {
    var stream = gulp.src(config.bower_components_required)
        .pipe(sourcemaps.init())
        .pipe(concat('bcapp-pattern-lab-all-deps.js'))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(config.js.build + '/bcapp'))
        .pipe(reload({stream:true}));

    return stream;
}

function concatWebsite() {
    var stream = gulp.src([
            config.dest.src + '/website/js/**/*.js',
            '!' + config.dest.src + '/website/js/**/*.scenario.js',
            '!' + config.dest.src + '/website/js/**/*.spec.js'
        ])
        .pipe(sourcemaps.init())
        .pipe(babel())
        .pipe(concat('website.js'))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(config.js.build + '/website'))
        .pipe(reload({stream:true}));

    return stream;
}

function concatVendorScripts() {
    var stream = gulp.src(config.bower_components)
        .pipe(concat('vendor.js'))
        .pipe(gulp.dest(config.js.build))
        .pipe(reload({stream:true}));

    return stream;
}

gulp.task('concat:bcappPatternLab', [
    'jshint:bcappPatternLab',
    'html2js:bcappPatternLab',
    'concat:bcappPatternLabDeps'
], concatBcappPatternLabComponents);

gulp.task('concat:bcappPatternLabDeps', concatBcappPatternLabDeps);

gulp.task('concat:website', [
    'concat:vendor',
    'jshint:website',
    'html2js:website'
], concatWebsite);

gulp.task('concat:vendor', concatVendorScripts);
