/* */ 
"format global";
module.exports = function(config) {
    config.set({
        'frameworks': [
            'jasmine'
        ],
        'plugins': [
            'karma-jasmine',
            'karma-phantomjs-launcher',
            'karma-coverage'
        ],
        'reporters': 'dots',
        'port': 9018,
        'runnerPort': 9100,
        'singleRun': true,
        'background': false,
        'urlRoot': '/',
        'autoWatch': false,
        'logLevel': 'ERROR',
        'browsers': [
            'PhantomJS'
        ]
    });
};
