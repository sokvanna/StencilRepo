/* */ 
"format global";
var gulp = require('gulp'),
    rename = require('gulp-rename'),
    fs = require('fs'),
    colors = require('colors'),
    config = require('../config'),
    svgProdFolder = '/svg/production',
    ICON_SIZE = '_24px';

function getDirectories(path) {
    if (fs.existsSync(path)) {
        // List of root directories
        return fs.readdirSync(path).filter(function(file) {
            return fs.statSync(path + '/' + file).isDirectory();
        });
    }
}

function getIconFiles(path) {
    // Get all the files names in a folder
    return fs.readdirSync(path, function(err, files) {
        return files;
    });
}

function filterIconFiles(files, path) {
    // We only want the 24px ones for now
    return files.filter(function(file) { return file.substr(-9) === ICON_SIZE + '.svg'; }).map(function(file) {
        // We need the full file path for each icon though
        return path + '/' + file;
    });
}

function icons() {

    var iconFolders = getDirectories(config.materialDesignIcons.bower),
        folderPath,
        iconFiles = [],
        filteredIcons,
        stream;

    if (iconFolders.length === 0) {
        console.warn('Have you '.yellow + 'bower install'.red + 'ed recently? Missing Google Material Design Icons assets.'.yellow);
        return false;
    }

    iconFolders.forEach(function(folder) {

        folderPath = config.materialDesignIcons.bower + '/' + folder + svgProdFolder;

        if (fs.existsSync(folderPath)) {
            filteredIcons = filterIconFiles(getIconFiles(folderPath), folderPath);
            iconFiles = iconFiles.concat(filteredIcons);
        }

    });

    stream =  gulp.src(iconFiles)
        .pipe(rename(function(path) {
            path.basename = path.basename.replace(ICON_SIZE, '').replace(/_/g, '-');
        }))
        .pipe(gulp.dest(config.materialDesignIcons.src));

    return stream;
}

gulp.task('material-design-icons', icons);
