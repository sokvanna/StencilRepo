/* */ 
"format global";
var gulp = require('gulp'),
    karma = require('gulp-karma'),
    config = require('../config'),
    bcappPatternLabScripts = []
        .concat(
            config.bower_components,
            config.bower_components_required,
            [
                config.js.build + '/bcapp/*.js',
                config.js.src + '/**/*.spec.js'
            ]
        ),
    websiteScripts = [
        config.js.build + '/vendor.js',
        config.js.build + '/website/*.js',
        config.dest.src + '/website/js/**/*.spec.js'
    ];

function testScripts(sources) {
    var stream = gulp.src(sources)
        .pipe(karma({
            configFile: './gulp/tasks/karma.conf.js',
            singleRun: true
        }));

    return stream;
}

gulp.task('karma:bcappPatternLab', [
    'concat:bcappPatternLab'
], testScripts.bind(null, bcappPatternLabScripts));

gulp.task('karma:website', [
    'concat:website'
], testScripts.bind(null, websiteScripts));
