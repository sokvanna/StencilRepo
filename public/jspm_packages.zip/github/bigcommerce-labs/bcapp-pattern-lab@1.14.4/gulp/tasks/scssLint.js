/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    scsslint = require('gulp-scss-lint');

function scssLint() {

    var stream = gulp.src([
            config.css.src + '/**/*.scss',
            '!' + config.css.src + '/sprites/design-icons/**/*.scss',
            config.dest.src + '/website/scss/**/*.scss'
        ])
        .pipe(scsslint({ bundleExec: true }))
        .pipe(scsslint.failReporter());

    return stream;

}

gulp.task('scss-lint', scssLint);
