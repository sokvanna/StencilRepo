/* */ 
"format global";
var gulp = require('gulp'),
    concat = require('gulp-concat'),
    html2js = require('gulp-html2js'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    browserSync = require('browser-sync'),
    reload = browserSync.reload,
    replace = require('gulp-replace'),
    fs = require('fs'),
    codemirrorReplaceKey = 'codemirror-replace';

function bcappPatternLabTemplates() {

    var stream = gulp.src([
            config.js.src + '/**/*.html'
        ])
        .pipe(html2js({
            outputModuleName: 'bcapp-pattern-lab-templates',
            useStrict: true,
            rename: function(modulePath) {
                if (modulePath.indexOf('src/js/foundation/template/') !== -1) {
                    //rename the file path to match what angular-foundation expects
                    var moduleName = modulePath.replace('src/js/foundation/template/', '').replace('.html', '');
                    return 'template' + '/' + moduleName + '.html';
                }
                return modulePath;
            }
        }))
        .on('error', handleErrors)
        .pipe(concat('bcapp-pattern-lab-all-templates.js'))
        .pipe(gulp.dest(config.js.build + '/bcapp/'))
        .pipe(reload({stream:true}));

    return stream;

}

function websiteTemplates() {

    var stream = gulp.src([
        config.templates.src + '/**/*.tpl.html'
    ])
        .pipe(replace(/codemirror-replace\(.*\)/g, function(match) {
            var filePath = match.slice(codemirrorReplaceKey.length + 1, -1);

            return fs.readFileSync(filePath, 'utf8').trim();
        }))
        .pipe(html2js({
            outputModuleName: 'website-templates',
            useStrict: true
        }))
        .on('error', handleErrors)
        .pipe(concat('website-templates.js'))
        .pipe(gulp.dest(config.js.build + '/website/'))
        .pipe(reload({stream:true}));

    return stream;

}

gulp.task('html2js:bcappPatternLab', bcappPatternLabTemplates);
gulp.task('html2js:website', websiteTemplates);
