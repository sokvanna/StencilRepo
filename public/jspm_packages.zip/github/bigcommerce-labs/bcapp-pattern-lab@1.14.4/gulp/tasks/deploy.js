/* */ 
"format global";
var gulp = require('gulp'),
    runSequence = require('run-sequence');

gulp.task('deploy', function(callback) {
    runSequence(
        'clean:release',
        'build',
        [
            'uglify',
            'css-min'
        ],
        'rename-min',
        [
            'staticAssets',
            'copy:public'
        ],
        'htmlReplace:deploy',
        callback
    );
});
