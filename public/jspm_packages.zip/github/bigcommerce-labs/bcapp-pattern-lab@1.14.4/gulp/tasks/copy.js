/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    browserSync = require('browser-sync'),
    p = require('../../package.json'),
    reload = browserSync.reload;

function copySVG() {
    var stream =  gulp.src(config.svg.build + '/**/*')
        .pipe(gulp.dest(config.svg.dist));

    return stream;
}

function copyFonts() {
    var stream =  gulp.src(config.fonts.build + '/**/*')
        .pipe(gulp.dest(config.fonts.dist));

    return stream;
}

function copyImages() {
    var stream =  gulp.src(config.images.build + '/**/*')
        .pipe(gulp.dest(config.images.dist));

    return stream;
}

function copyJS() {
    var stream =  gulp.src([
            config.js.build + '/bcapp/bcapp-pattern-lab.js',
            config.js.build + '/bcapp/bcapp-pattern-lab.min.js'
        ])
        .pipe(gulp.dest(config.js.dist));

    return stream;
}

function copyCSS() {
    var stream =  gulp.src([
            config.css.build + '/bcapp-pattern-lab.css',
            config.css.build + '/bcapp-pattern-lab.min.css'
        ])
        .pipe(gulp.dest(config.css.dist));

    return stream;
}

function copySCSS() {
    var stream =  gulp.src(config.css.src + '/**/*')
        .pipe(gulp.dest(config.dest.dist + '/scss'));

    return stream;
}

function copyPublic() {
    var stream =  gulp.src(config.dest.build + '/**/*')
        .pipe(gulp.dest(config.dest.public));

    return stream;
}

function copyTransclude() {
    // Only include the component assets (bcapp-pattern-lab), not the example app assets (website)
    var stream = gulp.src(config.dest.build + '/**/bcapp-*.{css,js}')
        .pipe(gulp.dest(config.bcAppDirectory + '/vendor/bower_components/' + p.name + '/build'));

    return stream;
}

gulp.task('copy:svg', copySVG);
gulp.task('copy:fonts', copyFonts);
gulp.task('copy:images', copyImages);
gulp.task('copy:css', copyCSS);
gulp.task('copy:scss', copySCSS);
gulp.task('copy:js', copyJS);
gulp.task('copy:public', copyPublic);
gulp.task('copy:transclude', copyTransclude);
