/* */ 
"format global";
var gulp = require('gulp'),
    fm = require('gulp-front-matter'),
    hb = require('gulp-hb'),
    browserSync = require('browser-sync'),
    reload = browserSync.reload,
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    replace = require('gulp-replace'),
    fs = require('fs');

function templates() {
    var stream = gulp
        .src(config.templates.src + '/*.html')
        .pipe(replace(/codemirror-replace\(.*\)/g, function(match) {
            var filePath = match.slice(19, -1);

            return fs.readFileSync(filePath, 'utf8').trim();
        }))
        .pipe(fm({ property: 'meta' }))
        .pipe(hb({
            data: config.templates.src + '/data/**/*.js',
            helpers: './node_modules/handlebars-layouts',
            partials: config.templates.src + '/partials/**/*.*'
        }))
        .on('error', handleErrors)
        .pipe(gulp.dest(config.dest.build))
        .pipe(reload({stream:true}));

    return stream;
}

gulp.task('templates', ['clean:templates'], templates);
