/* */ 
"format global";
var gulp = require('gulp'),
    del = require('del'),
    config = require('../config');

gulp.task('clean:release', ['clean:public'], function(cb) {
    del([
        config.dest.dist
    ], cb);
});

gulp.task('clean:public', function(cb) {
    del([
        config.dest.public
    ], cb);
});

gulp.task('clean:build', function(cb) {
    del([
        config.dest.build
    ], cb);
});

gulp.task('clean:templates', function(cb) {
    del([
        config.dest.build + '/*.html'
    ], cb);
});

gulp.task('clean:js', function(cb) {
    del([
        config.js.build
    ], cb);
});

gulp.task('clean:images', function(cb) {
    del([
        config.images.build
    ], cb);
});

gulp.task('clean:styles', function(cb) {
    del([
        config.css.build
    ], cb);
});
