/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    nodeSass = require('gulp-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    browserSync = require('browser-sync'),
    reload = browserSync.reload;

function styles() {

    var stream = gulp.src([
            config.css.src + '/*.scss'
        ])
        .pipe(nodeSass({
            includePaths: ['scss'],
            outputStyle: 'nested',
            errLogToConsole: false
        }))
        .on('error', handleErrors)
        .pipe(autoprefixer({
            browsers: ['last 2 versions', 'ie 10']
        }))
        .pipe(gulp.dest(config.css.build))
        .pipe(reload({stream:true}));

    return stream;

}

gulp.task('styles', ['clean:styles', 'scss-lint'], styles);
