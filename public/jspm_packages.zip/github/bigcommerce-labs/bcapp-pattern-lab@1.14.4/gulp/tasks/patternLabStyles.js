/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    nodeSass = require('gulp-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    browserSync = require('browser-sync'),
    reload = browserSync.reload;

function websiteStyles() {

    var stream = gulp.src([
            config.dest.src + '/website/scss/website.scss'
        ])
        .pipe(nodeSass())
        .on('error', handleErrors)
        .pipe(autoprefixer({
            browsers: ['last 2 versions', 'ie 10']
        }))
        .pipe(gulp.dest(config.css.build))
        .pipe(reload({stream:true}));

    return stream;

}

gulp.task('websiteStyles', websiteStyles);
