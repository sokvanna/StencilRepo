/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config');

gulp.task('watch', function() {

    // styles
    gulp.watch([
        config.css.src + '/**/*.scss',
        config.dest.src + '/vendor/bower_components/citadel/dist/**/*.scss'
    ], ['styles', 'websiteStyles']);

    gulp.watch([
        config.dest.src + '/website/scss/**/*.scss'
    ], ['websiteStyles']);

    // images
    gulp.watch(config.images.src + '/**', ['images']);

    gulp.watch([
        config.svg.src + '/**',
        '!' + config.icons.src + '/**'
    ], ['svg']);

    gulp.watch([
        config.icons.src + '/**/*'
    ], ['icons:watch']);

    // html
    gulp.watch([
        config.templates.src + '/*.html',
        config.templates.src + '/partials/**/*.hbs'
    ], ['templates']);

    // js
    gulp.watch(config.js.src + '/**/*', ['karma:bcappPatternLab']);

    gulp.watch(config.dest.src + '/website/js/**/*', ['karma:website']);
});
