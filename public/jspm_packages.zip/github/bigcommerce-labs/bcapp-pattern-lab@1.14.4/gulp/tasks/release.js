/* */ 
"format global";
var gulp = require('gulp'),
    runSequence = require('run-sequence');

gulp.task('bump', ['prompt:bump']);

gulp.task('release', function(callback) {
    runSequence(
        'deploy',
        'prompt:commit',
        callback
    );
});
