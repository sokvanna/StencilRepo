/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    jshint = require('gulp-jshint'),
    jshintConfigPath = './.jshintrc',
    bcappPatternLabScripts = config.js.src + '/**/*.js',
    websiteScripts = config.dest.src + '/website/js/**/*.js';

function lintScripts(sources) {
    var stream = gulp.src(sources)
        .pipe(jshint(jshintConfigPath))
        .pipe(jshint.reporter('jshint-stylish'))
        .pipe(jshint.reporter('fail'));

    return stream;
}

gulp.task('jshint:bcappPatternLab', lintScripts.bind(null, bcappPatternLabScripts));
gulp.task('jshint:website', lintScripts.bind(null, websiteScripts));
