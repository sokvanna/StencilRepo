/* */ 
angular.module('website.alerts.state', [
    'ui.router',
    'website.alerts.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.alerts', {
                url: '/alerts',
                templateUrl: 'src/website/js/examples/alerts/alerts.tpl.html',
                controller: 'AlertsCtrl as alertsCtrl'
            });
    });
