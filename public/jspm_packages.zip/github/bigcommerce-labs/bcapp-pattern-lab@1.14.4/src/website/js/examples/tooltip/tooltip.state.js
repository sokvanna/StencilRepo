/* */ 
angular.module('website.tooltip.state', [
    'ui.router'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.tooltip', {
                url: '/tooltip',
                templateUrl: 'src/website/js/examples/tooltip/tooltip.tpl.html'
            });
    });
