/* */ 
angular.module('website.buttons.state', [
    'ui.router',
    'website.buttons.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.buttons', {
                url: '/buttons',
                templateUrl: 'src/website/js/examples/buttons/buttons.tpl.html',
                controller: 'ButtonsCtrl as buttonsCtrl'
            });
    });
