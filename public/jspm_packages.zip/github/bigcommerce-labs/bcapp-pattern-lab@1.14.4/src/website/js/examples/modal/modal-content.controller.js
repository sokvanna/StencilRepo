/* */ 
angular.module('website.modal-content.controller', [])

    .controller('ModalContentCtrl', function($modalInstance) {
        var ctrl = this;

        ctrl.ok = ok;
        ctrl.cancel = cancel;

        function ok($event) {
            $event.preventDefault();

            $modalInstance.close('OK');
        }

        function cancel($event) {
            $event.preventDefault();

            $modalInstance.dismiss('Canceled');
        }
    });
