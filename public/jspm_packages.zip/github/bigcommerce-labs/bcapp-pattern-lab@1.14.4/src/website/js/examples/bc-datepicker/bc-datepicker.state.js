/* */ 
angular.module('website.bc-datepicker.state', [
    'ui.router',
    'website.bc-datepicker.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.bc-datepicker', {
                url: '/bc-datepicker',
                templateUrl: 'src/website/js/examples/bc-datepicker/bc-datepicker.tpl.html',
                controller: 'BcDatepickerCtrl as bcDatepickerCtrl'
            });
    });
