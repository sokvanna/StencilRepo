/* */ 
angular.module('website.switch', [
    'website.switch.controller'
]);
