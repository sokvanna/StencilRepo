/* */ 
angular.module('website.switch.controller', [])

    .controller('PatternLabSwitchCtrl', function() {
        var ctrl = this;

        ctrl.switchOne = false;
        ctrl.switchTwo = true;
        ctrl.switchThree = false;
        ctrl.switchFour = true;
        ctrl.switchFive = false;
    });
