/* */ 
angular.module('website.bc-datepicker.controller', [])
    .controller('BcDatepickerCtrl', function() {
        var ctrl = this;

        ctrl.options = {};
    });

