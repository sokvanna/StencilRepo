/* */ 
angular.module('website.loading-indicators.state', [
    'ui.router',
    'website.loading-indicators.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.loading', {
                url: '/loaders',
                templateUrl: 'src/website/js/examples/loading-indicators/loading-indicators.tpl.html',
                controller: 'LoadingIndicatorsCtrl as loadingIndicatorsCtrl'
            });
    });
