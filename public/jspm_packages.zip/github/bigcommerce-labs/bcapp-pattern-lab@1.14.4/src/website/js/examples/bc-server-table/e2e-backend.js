/* */ 
angular.module('e2e-backend', [
    'ngMockE2E'
])
    .run(function($httpBackend) {
        $httpBackend.whenGET(/\/table.json.*/).respond(apiResponse);
        $httpBackend.whenGET(/.*/).passThrough();

        function apiResponse(status, data) {
            var items, pagination, rows, rowToShow, sortBy, fromRow, toRow, limit, page;
            rows = [
                { 'name': 'Ritual Coffee Roasters', 'star': '★★★★★', 'sf-location': 'Hayes Valley'},
                { 'name': 'Blue Bottle', 'star': '★★★★★', 'sf-location': 'Hayes Valley' },
                { 'name': 'CoffeeShop', 'star': '★★★', 'sf-location': 'Bernal Heights' },
                { 'name': 'Spike\'s Coffee & Teas', 'star': '★★★', 'sf-location': 'Castro' },
                { 'name': 'La Boulange', 'star': '★★', 'sf-location': 'Cole Valley' },
                { 'name': 'Dynamo Donut and Coffee', 'star': '★★★★★', 'sf-location': 'Cow Hollow' },
                { 'name': 'The Mill', 'star': '★★★★', 'sf-location': 'Divisadero' },
                { 'name': 'Piccino Coffee Bar', 'star': '★★★', 'sf-location': 'Dogpatch' },
                { 'name': 'Philz', 'star': '★★★', 'sf-location': 'Downtown' },
                { 'name': 'Duboce Park Cafe', 'star': '★★', 'sf-location': 'Duboce Triangle' },
                { 'name': 'Blue Bottle', 'star': '★★★★★', 'sf-location': 'Embarcadero' },
                { 'name': 'Four Barrel', 'star': '★★★', 'sf-location': 'Excelsior' },
                { 'name': 'Coffee Bar', 'star': '★★★★★', 'sf-location': 'FiDi' },
                { 'name': 'Biscoff Coffee Corner', 'star': '★★★', 'sf-location': 'Fisherman\'s Wharf' },
                { 'name': 'Fifty/Fifty Coffee and Tea', 'star': '★★★', 'sf-location': 'Inner Richmond' },
                { 'name': 'Beanery', 'star': '★★★', 'sf-location': 'Inner Sunset' },
                { 'name': 'Cafe du Soleil', 'star': '★★', 'sf-location': 'Lower Haight' },
                { 'name': 'Peet\'s', 'star': '★', 'sf-location': 'The Marina' },
                { 'name': 'Sightglass', 'star': '★★★★', 'sf-location': 'The Mission' },
                { 'name': 'Contraband Coffee Bar', 'star': '★★★★', 'sf-location': 'Nob Hill' },
                { 'name': 'Martha & Bros Coffee', 'star': '★★★', 'sf-location': 'Noe Valley' },
                { 'name': 'Réveille', 'star': '★★★', 'sf-location': 'North Beach' },
                { 'name': 'Cup Coffee Bar', 'star': '★★★', 'sf-location': 'Outer Mission' },
                { 'name': 'Garden House Cafe', 'star': '★★★', 'sf-location': 'Outer Richmond' },
                { 'name': 'Andytown Coffee Roasters', 'star': '★★★', 'sf-location': 'Outer Sunset' },
                { 'name': 'Jane on Fillmore', 'star': '★★', 'sf-location': 'Pacific Heights' },
                { 'name': 'Saint Frank Coffee', 'star': '★★★', 'sf-location': 'Polk' },
                { 'name': 'Farley’s', 'star': '★★★', 'sf-location': 'Potrero Hill' },
                { 'name': 'House of Snacks', 'star': '★★★', 'sf-location': 'The Presidio' },
                { 'name': 'The Brew', 'star': '★★★', 'sf-location': 'Russian Hill' },
                { 'name': 'Wicked Grounds', 'star': '★★★', 'sf-location': 'SOMA' },
                { 'name': 'Starbucks', 'star': '★', 'sf-location': 'Union Square' },
                { 'name': 'Flywheel Coffee Roasters', 'star': '★★★★★', 'sf-location': 'Upper Haight' }
            ];
            limit = parseInt(getParameterByName('limit'), 10) || 11;
            page = parseInt(getParameterByName('page'), 10) || 1;

            if (getParameterByName('sort-by')) {
                sortBy = getParameterByName('sort-by');
                if (getParameterByName('sort-order') === 'dsc') {
                    sortBy = '-' + sortBy;
                }
                rows.sort(dynamicSort(sortBy));
            }

            pagination = {
                'limit': limit,
                'page': page,
                'pages': Math.ceil(rows.length / limit),
                'numItems': rows.length
            };
            toRow = pagination.limit * pagination.page;
            fromRow = toRow - pagination.limit;

            if (fromRow >= 0 && toRow >= 0) {
                rowToShow = rows.slice(fromRow, toRow);
            } else {
                rowToShow = rows;
            }

            items = {
                'rows': rowToShow,
                'pagination': pagination,
                'sort-by': getParameterByName('sort-by'),
                'sort-order': getParameterByName('sort-order')
            };

            function dynamicSort(property) {
                var sortOrder = 1;
                if(property[0] === '-') {
                    sortOrder = -1;
                    property = property.substr(1);
                }
                return function (a,b) {
                    var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
                    return result * sortOrder;
                };
            }

            function getParameterByName(name) {
                name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
                var regex = new RegExp('[\\?&]' + name + '=([^&#]*)'),
                    results = regex.exec(data);
                return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
            }

            return [200, items, {}];
        }
    });
