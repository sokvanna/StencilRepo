/* */ 
describe('app specs', function () {

    beforeEach(module('website'));

    describe('dummy test', function() {
        it('should pass', function () {
            expect(true).toBe(true);
        });
    });

});
