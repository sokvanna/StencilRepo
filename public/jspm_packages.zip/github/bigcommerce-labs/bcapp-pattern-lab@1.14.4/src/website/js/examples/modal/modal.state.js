/* */ 
angular.module('website.modal.state', [
    'ui.router',
    'website.modal.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.modal', {
                url: '/modal',
                templateUrl: 'src/website/js/examples/modal/modal.tpl.html',
                controller: 'ModalCtrl as modalCtrl'
            });
    });
