/* */ 
angular.module('website.modal.controller', [
   'website.modal-content.controller'
])

    .controller('ModalCtrl', function($modal) {
        var ctrl = this;
        ctrl.openUnformattedModal = openUnformattedModal;
        ctrl.openFormattedModal = openFormattedModal;
        ctrl.openSmallModal = openSmallModal;

        function openUnformattedModal($event) {
            $event.preventDefault();
            $modal.open({
                controller: 'ModalContentCtrl as modalContentCtrl',
                templateUrl: 'src/website/js/examples/modal/modal-unformatted.tpl.html'
            });
        }

        function openFormattedModal($event) {
            $event.preventDefault();
            $modal.open({
                controller: 'ModalContentCtrl as modalContentCtrl',
                templateUrl: 'src/website/js/examples/modal/modal-formatted.tpl.html'
            });
        }

        function openSmallModal($event) {
            $event.preventDefault();
            $modal.open({
                controller: 'ModalContentCtrl as modalContentCtrl',
                templateUrl: 'src/website/js/examples/modal/modal-small.tpl.html',
                windowClass: 'modal--small'
            });
        }
    });
