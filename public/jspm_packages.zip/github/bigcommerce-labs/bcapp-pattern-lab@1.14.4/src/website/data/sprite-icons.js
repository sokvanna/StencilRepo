/* */ 
"format global";
var IconsFromFolder = require('./utils/IconsFromFolders'),
    iconsFromFolder = new IconsFromFolder(),
    config = require('../../../gulp/config'),
    spritePath = config.spriteImages.src;

module.exports = {
    sprites: iconsFromFolder.getIcons(spritePath, 'raster')
};
