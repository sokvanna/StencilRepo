/* */ 
"format global";
'use strict';
var fs = require('fs'),
    config = require('../../../gulp/config');

function getDirectories(path) {
    return fs.readdirSync(path).filter(function (file) {
        return fs.statSync(path + '/' + file).isDirectory();
    });
}

function sortByName(a, b) {
    // sort alphabetically by name
    if (a.name > b.name) {
        return 1;
    }
    if (a.name < b.name) {
        return -1;
    }
    return 0;
}

function getJsComponentNames() {
    return getDirectories(config.dest.src + '/website/js/examples').map(function(dirName) {
        return {
            name: dirName.replace(/-/g, ' '),
            href: dirName
        }
    }).sort(sortByName);
}

module.exports = {
    jsComponents: getJsComponentNames()
};
