/* */ 
"format global";
var fs = require('fs');

function IconsFromFolders(path) {
    this.path = path;
}

IconsFromFolders.prototype.getIconDirectories = function(path) {
    if (fs.existsSync(path)) {
        // List of root directories
        return fs.readdirSync(path).filter(function(file) {
            return fs.statSync(path + '/' + file).isDirectory();
        });
    }
};

IconsFromFolders.prototype.getIconFiles = function(path) {
    // Get all the files names in a folder
    return fs.readdirSync(path, function(err, files) {
        return files;
    });
};

IconsFromFolders.prototype.filterIconRetinaIcons = function(files) {
    // We don't want the @2x ones
    return files.filter(function(file) { return file.substr(-7) !== '@2x.png'; });
};

IconsFromFolders.prototype.getIconFilenames = function(files) {
    return files.map(function(file) {
        return {
            name: file.replace('.png', '').replace('.svg', '')
        };
    });
};

IconsFromFolders.prototype.getIcons = function(rootFolderPath, type) {

    var that = this,
        groupFolderPath,
        iconFiles,
        iconFilenames,
        iconDirectories,
        iconGroups = [];

    iconDirectories = this.getIconDirectories(rootFolderPath);

    iconDirectories.forEach(function(folder) {
        groupFolderPath = rootFolderPath + '/' + folder;

        iconFiles = that.getIconFiles(groupFolderPath);

        if (type === 'raster') {
            iconFiles = that.filterIconRetinaIcons(iconFiles);
        }

        iconFilenames = that.getIconFilenames(iconFiles);
        iconGroups = iconGroups.concat({
            group: folder.replace(/-/g, ' '),
            icons: iconFilenames
        });
    });

    return iconGroups;
};

module.exports = IconsFromFolders;
