/**
 * @description Sprite directive used to load an icon from an image sprite,
 *              simliar to the icon directive but less SVG
 * @example
 * <sprite glyph="ic-amex"></sprite>
 */

angular.module('bcapp-pattern-lab.sprite.directive', [])
    .directive('sprite', function spriteDirective() {
        return {
            restrict: 'E',
            scope: {
                glyph: '@'
            },
            compile: spriteDirectiveCompile
        };

        function spriteDirectiveCompile(tElement) {
            tElement.addClass('sprite');
            tElement.attr('aria-hidden', true);

            return function spriteDirectiveLink($scope, element, attrs) {
                attrs.$observe('glyph', (newValue) => {
                    element.attr('class', 'sprite sprite--' + newValue);
                });
            };
        }
    });
