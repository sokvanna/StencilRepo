/* */ 
describe('bcSortBy directive', function() {
    var tableId = 'demo-table',
        demoTable,
        elem,
        scope,
        sortByName,
        sortByPrice;

    function compileDirective(tpl) {
        tpl = tpl || '<div><bc-sort-by table-id="' + tableId + '" sort-value="name"></bc-sort-by><bc-sort-by table-id="' + tableId + '" sort-value="price"></bc-sort-by></div>';
        inject(function($compile) {
            elem = $compile(tpl)(scope);
        });
        // $digest to finalize the directive generation
        scope.$digest();
    }

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.bc-server-table.sort-by.directive'));
    beforeEach(inject(function(bcServerTableFactory) {
        demoTable = bcServerTableFactory.create(tableId, {
            sortDirValues: {
                asc: 'asc',
                desc: 'desc'
            },
            rowIdKey: 'id'
        });

        demoTable.sortBy = 'price';
        demoTable.sortDir = 'asc';
        demoTable.setPaginationValues = angular.noop;
        demoTable.updateTable = angular.noop;
        demoTable.updateSort = function(sortBy, sortDir) {
            demoTable.sortBy = sortBy;
            demoTable.sortDir = sortDir;
        };
    }));

    // before each test, create a new fresh scope
    beforeEach(inject(function($rootScope) {
        scope = $rootScope.$new();
        compileDirective();
        sortByName = angular.element(elem.find('bc-sort-by')[0]).isolateScope();
        sortByPrice = angular.element(elem.find('bc-sort-by')[1]).isolateScope();
    }));

    describe('initialization', function() {
        it('should set sortBy value based on parent bcServerTable', function() {
            expect(sortByName.sortBy).toBe('price');
        });
    });

    describe('sort method', function() {
        it('should call the bcServerTable updateSort method', function() {
            spyOn(demoTable, 'updateSort');
            sortByName.sort();
            expect(demoTable.updateSort).toHaveBeenCalled();
        });

        it('should change the sortBy value to the new sortValue', function() {
            spyOn(demoTable, 'updateSort');
            sortByName.sort();
            expect(demoTable.updateSort).toHaveBeenCalledWith('name', 'asc');
        });

        it('should change the sortDir when the current sortBy matches the sortValue', function() {
            spyOn(demoTable, 'updateSort').and.callThrough();
            sortByName.sort();
            sortByName.sort();
            expect(demoTable.updateSort.calls.mostRecent().args).toEqual(['name', 'desc']);
            sortByName.sort();
            expect(demoTable.updateSort.calls.mostRecent().args).toEqual(['name', 'asc']);
        });

        it('should work with multiple directives under the same controller', function() {
            spyOn(demoTable, 'updateSort').and.callThrough();
            sortByName.sort();
            sortByName.sort();
            expect(demoTable.updateSort.calls.mostRecent().args).toEqual(['name', 'desc']);
            sortByPrice.sort();
            expect(demoTable.updateSort.calls.mostRecent().args).toEqual(['price', 'asc']);
            sortByPrice.sort();
            expect(demoTable.updateSort.calls.mostRecent().args).toEqual(['price', 'desc']);
            sortByName.sort();
            expect(demoTable.updateSort.calls.mostRecent().args).toEqual(['name', 'asc']);
        });
    });
});
