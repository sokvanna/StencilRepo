/* */ 
describe('trustAsHtml filter tests', function () {
    var strToTrust = '<p>{{ interpolatedText }}</p>',
        $compile,
        $filter,
        $interpolate,
        $scope,
        $sce,
        trustAsHtmlFilter;

    beforeEach(module('bcapp-pattern-lab.util.trustAsHtml'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $filter = $injector.get('$filter');
        $interpolate = $injector.get('$interpolate');
        $scope = $injector.get('$rootScope').$new();
        $sce = $injector.get('$sce');
    }));

    function compileTemplate() {
        var htmlElement;

        htmlElement = $compile('<div ng-bind-html="strToTrust | trustAsHtml"></div>')($scope);
        $scope.$digest();

        return htmlElement;
    }

    describe('trustAsHtml filter function', function () {
        beforeEach(function() {
            spyOn($sce, 'trustAsHtml');
            trustAsHtmlFilter = $filter('trustAsHtml');
        });

        it('should call $sce.trustAsHtml with the input string', function () {
            trustAsHtmlFilter(strToTrust);

            expect($sce.trustAsHtml).toHaveBeenCalledWith(strToTrust);
        });
    });

    describe('trustAsHtml filter in action', function() {
        it('should be used with ng-bind-html without angular throwing an error', function() {
            $scope.strToTrust = strToTrust;

            expect(compileTemplate($scope).find('p').length).toBe(1);
        });

        it('should be able to handle interpolatedText as well when combined with $interpolate', function() {
            var interpolatedText = $interpolate(strToTrust)({ interpolatedText: 'hello' });

            $scope.strToTrust = interpolatedText;

            expect(compileTemplate($scope).html()).toContain('hello');
        });
    });
});
