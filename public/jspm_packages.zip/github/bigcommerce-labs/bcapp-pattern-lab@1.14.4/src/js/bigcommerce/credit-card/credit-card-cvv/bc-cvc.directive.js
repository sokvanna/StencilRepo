/**
 * @name bc-cvc directive
 * @description A custom complementary directive to angular-credit-card's `ccCvc` directive.
 * To support allowing an optional cvc field (i.e. Securenet), this directive must override
 * the validation provided by ccCvc directive.
 */
angular.module('bcapp-pattern-lab.credit-card.bc-cvc', [
    'credit-cards',
])
    .directive('bcCvc', function bcCvcDirective($parse) {
        return {
            link: function bcCvcLink(scope, element, attributes, ngModel) {
                // override the validation to always return valid
                // if cvc is not required
                if (!$parse(attributes.ngRequired)(scope)) {
                    ngModel.$validators.ccCvc = () => true;
                }
            },
            priority: 5, // higher priority to ensure ccCvc's link is ran first
            require: 'ngModel',
            restrict: 'A',
        };
    });
