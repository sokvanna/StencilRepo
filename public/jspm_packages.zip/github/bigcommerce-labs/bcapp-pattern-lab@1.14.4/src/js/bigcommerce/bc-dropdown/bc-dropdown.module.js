/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown', [
    'bcapp-pattern-lab.bc-dropdown.directive',
    'bcapp-pattern-lab.bc-dropdown-toggle.directive',
    'bcapp-pattern-lab.bc-dropdown-menu.directive'
]);
