/* */ 
angular.module('bcapp-pattern-lab.bc-server-table', [
    'bcapp-pattern-lab.bc-server-table.directive',
    'bcapp-pattern-lab.bc-server-table.sort-by.directive',
    'bcapp-pattern-lab.bc-server-table-factory.service'
]);
