/* */ 
angular.module('bcapp-pattern-lab.switch', [
    'bcapp-pattern-lab.switch.directive'
]);
