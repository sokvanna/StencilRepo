/* */ 
angular.module('bcapp-pattern-lab.form-field-errors.directive', [])
    .directive('formFieldErrors', function formFieldErrorsDirective() {
        return {
            replace: true,
            require: '^form',
            restrict: 'EA',
            templateUrl: 'src/js/bigcommerce/form-field-errors/form-field-errors.tpl.html',
            transclude: true,
            link: {
                // Pre-link is required, as we have to inject our scope properties before the child
                // form-field-error directive (and its internal ng-message directive's) post-link functions
                pre: function formFieldErrorsPreLink(scope, element, attrs, formCtrl) {
                    // Property name can be inherited from parent scope, such as from the form-field directive
                    var property = scope.property || attrs.property,
                        propertyField = formCtrl[property];

                    // Inherited by form-field-error directive. Lives directly on scope because the require
                    // property does not work well with directive controller instances
                    scope.formCtrl = formCtrl;
                    scope.property = property;
                    scope.propertyField = propertyField;
                }
            }
        };
    });
