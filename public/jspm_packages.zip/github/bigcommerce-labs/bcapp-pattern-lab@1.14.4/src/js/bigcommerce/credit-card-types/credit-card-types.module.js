/* */ 
angular.module('bcapp-pattern-lab.credit-card-types', [
    'bcapp-pattern-lab.credit-card-types.constant',
    'bcapp-pattern-lab.credit-card-types.controller',
    'bcapp-pattern-lab.credit-card-types.directive',
]);
