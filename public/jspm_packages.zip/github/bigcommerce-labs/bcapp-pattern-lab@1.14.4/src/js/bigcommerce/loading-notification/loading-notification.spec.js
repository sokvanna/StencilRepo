/* */ 
describe('Directive: loading', function() {
    var $compile,
        $scope;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.loading-notification'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope) {
        var element = angular.element('<loading-notification>' + '</loading-notification>');

        return $compile(element)(scope);
    }

    describe('Request in progress', function() {
        it('should set requestInProgress to true on event ajaxRequestRunning(true)', function() {
            var element = compileDirective($scope);
            $scope.$digest();

            expect(element.scope().requestInProgress).toBeFalsy();
            $scope.$emit('ajaxRequestRunning', true);
            expect(element.scope().requestInProgress).toBe(true);
        });

        it('should set requestInProgress to false on event ajaxRequestRunning(false)', function() {
            var element = compileDirective($scope);
            $scope.$digest();

            $scope.$emit('ajaxRequestRunning', true);
            $scope.$emit('ajaxRequestRunning', false);
            expect(element.scope().requestInProgress).toBe(false);
        });
    });
});
