/* */ 
angular.module('bcapp-pattern-lab.loading-notification.directive', [])
    .directive('loadingNotification', function loadingNotificationDirective($rootScope) {
        return {
            restrict: 'E',
            templateUrl: 'src/js/bigcommerce/loading-notification/loading-notification.tpl.html',

            link: function(scope) {
                $rootScope.$on('ajaxRequestRunning', function(event, val) {
                    scope.requestInProgress = val;
                });
            }
        };
    });
