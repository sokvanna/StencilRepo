/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown-toggle.directive', [])
    .directive('bcDropdownToggle', function bcDropdownToggleDirective($compile) {
        return {
            restrict: 'A',
            terminal: true,
            priority: 1001, // set higher than ng-repeat to prevent double compilation
            require: '^bcDropdown',
            compile: function bcDropdownToggleDirectiveCompile(tElement) {
                tElement.removeAttr('bc-dropdown-toggle');

                return function bcDropdownToggleDirectiveLink(scope, element, attrs, bcDropdownCtrl) {
                    element.attr('dropdown-toggle', '#' + bcDropdownCtrl.getUniqueId());
                    $compile(element)(scope);
                };
            }
        };
    });
