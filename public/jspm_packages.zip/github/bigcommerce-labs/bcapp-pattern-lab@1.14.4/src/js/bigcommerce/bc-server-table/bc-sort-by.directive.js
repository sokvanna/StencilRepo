/* */ 
angular.module('bcapp-pattern-lab.bc-server-table.sort-by.directive', [
    'bcapp-pattern-lab.bc-server-table-factory.service'
])
    .directive('bcSortBy', function bcSortByDirective($log, bcServerTableFactory) {
        var directive = {
            templateUrl: 'src/js/bigcommerce/bc-server-table/bc-sort-by.tpl.html',
            restrict: 'E',
            transclude: true,
            scope: {
                sortValue: '@',
                columnName: '@',
                tableId: '@'
            },
            require: '?^^bcServerTable',
            link: bcSortByDirectiveLink
        };

        function bcSortByDirectiveLink(scope, element, attrs, bcServerTableCtrl) {
            var bcServerTable,
                sortDirValues;

            if (scope.tableId) {
                bcServerTable = bcServerTableFactory.get(scope.tableId);
            } else if (bcServerTableCtrl) {
                bcServerTable = bcServerTableCtrl;
            } else {
                $log.error('bc-sort-by directive requires a table-id, or a parent bcServerTableCtrl directive.');
            }

            sortDirValues = bcServerTable.tableConfig.sortDirValues;

            scope.asc = sortDirValues.asc;
            scope.desc = sortDirValues.desc;
            scope.sortBy = bcServerTable.sortBy;
            scope.sortDir = bcServerTable.sortDir;
            scope.sort = sort;

            function sort($event) {
                var sortBy,
                    sortDir;

                if ($event) {
                    $event.preventDefault();
                }

                if (bcServerTable.sortBy === scope.sortValue) {
                    sortBy = bcServerTable.sortBy;
                    sortDir = bcServerTable.sortDir === scope.asc ? scope.desc : scope.asc;
                } else {
                    sortBy = scope.sortValue;
                    sortDir = scope.asc;
                }

                bcServerTable.updateSort(sortBy, sortDir);
            }
        }

        return directive;
    });
