/* */ 
angular.module('bcapp-pattern-lab.credit-card', [
    'credit-cards',
    'bcapp-pattern-lab.credit-card.bc-cvc',
    'bcapp-pattern-lab.credit-card.cc-expiry',
    'bcapp-pattern-lab.credit-card.directive',
    'gettext',
]);
