/* */ 
angular.module('bcapp-pattern-lab.loading-overlay.controller', [])
    .controller('LoadingOverlayCtrl', function LoadingOverlayCtrl($rootScope, $timeout) {
        var ctrl = this,
            defaultDebounce = 100,
            timeout;

        if (ctrl.debounce === undefined) {
            ctrl.debounce = defaultDebounce;
        }

        if (ctrl.useUiRouter) {
            $rootScope.$on('$stateChangeStart', startLoading);
            $rootScope.$on('$stateChangeSuccess', stopLoading);
            $rootScope.$on('$stateChangeError', stopLoading);
        }

        function startLoading(event) {
            if (event.defaultPrevented) {
                return;
            }

            timeout = $timeout(function startLoadingTimer() {
                ctrl.loading = true;
            }, ctrl.debounce);
        }

        function stopLoading(event) {
            if (event.defaultPrevented) {
                return;
            }

            $timeout.cancel(timeout);
            ctrl.loading = false;
        }
    });
