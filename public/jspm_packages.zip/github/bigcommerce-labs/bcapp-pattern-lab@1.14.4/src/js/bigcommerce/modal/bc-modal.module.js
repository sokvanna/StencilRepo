/*
 * This module modifies angular foundation's modal implementation. This does not create a new modal service/directive.
 * 
*/
angular.module('bcapp-pattern-lab.bc-modal', [
    'bcapp-pattern-lab.bc-modal.modalStack.service'
]);
