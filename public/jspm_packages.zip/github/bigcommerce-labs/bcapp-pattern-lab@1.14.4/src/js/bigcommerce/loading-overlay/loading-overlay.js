/* */ 
angular.module('bcapp-pattern-lab.loading-overlay', [
    'bcapp-pattern-lab.loading-overlay.directive'
]);
