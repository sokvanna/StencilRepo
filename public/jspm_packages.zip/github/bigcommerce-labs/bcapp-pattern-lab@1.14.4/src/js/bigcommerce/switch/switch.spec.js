/* */ 
describe('Directive: Switch', function() {
    var $compile,
        $scope;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.switch'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope, customElement) {
        var element;

        if (customElement) {
            element = angular.element(customElement);
        } else {
            element = angular.element('<switch ng-model="switchModel1"></switch>');
        }

        return $compile(element)(scope);
    }

    describe('initialization', function() {
        it('should start the switch in the correct position', function() {
            var initialValue = true,
                element;

            $scope.switchModel1 = initialValue;

            element = compileDirective($scope);

            $scope.$digest();

            expect(element.isolateScope().switchCtrl.value).toBe(initialValue);
        });
    });

    describe('behavior', function() {
        function toggle(element) {
            angular.element(element).find('input')[0].click();
        }

        it('should toggle the model value when clicked', function() {
            var initialValue = false,
                element;

            $scope.switchModel1 = initialValue;

            element = compileDirective($scope);

            $scope.$digest();

            toggle(element);

            expect(element.isolateScope().switchCtrl.value).toBe(!initialValue);

            toggle(element);

            expect(element.isolateScope().switchCtrl.value).toBe(initialValue);
        });

        it('should trigger ng-change after the model is updated', function() {
            var element;

            $scope.testFunc = angular.noop;

            spyOn($scope, 'testFunc');

            element = compileDirective($scope, '<switch ng-change="testFunc(switchModel1)" ng-model="switchModel1"></switch>');

            $scope.$digest();

            toggle(element);

            expect($scope.testFunc).toHaveBeenCalledWith(true);
        });
    });

    describe('Unique IDs', function() {

        it('should get a unique ID', function() {
            var element = compileDirective($scope),
                element2 = compileDirective($scope),
                id1, id2;

            $scope.$digest();

            id1 = element.isolateScope().switchCtrl.uniqueId;
            id2 = element2.isolateScope().switchCtrl.uniqueId;

            expect(id1).not.toEqual(id2);
        });

    });

    describe('Unique Aria IDs', function() {

        it('should get a unique ID for aria-describedby element', function() {
            var element = compileDirective($scope),
                element2 = compileDirective($scope),
                id1, id2;

            $scope.$digest();

            id1 = element.isolateScope().switchCtrl.ariaDescriptionID;
            id2 = element2.isolateScope().switchCtrl.ariaDescriptionID;

            expect(id1).not.toEqual(id2);
        });

    });

    describe('Toggle indication text', function() {

        var customEl = '<switch ' +
            'toggle-off-label="Off"' +
            'toggle-on-label="On"' +
            'ng-model="switchModel2">' +
            '</switch>',
            element,
            labelText;

        it('should set labelText to the off text option by default', function() {

            element = compileDirective($scope, customEl);

            $scope.$digest();

            labelText = element.isolateScope().switchCtrl.labelText;

            expect(labelText).toEqual('Off');

        });

    });

    describe('Set Icon switch', function() {

        var customEl = '<switch ' +
            'ng-model="switchModel2">' +
            '</switch>',
            customEl2 = '<switch ' +
            'has-icon ' +
            'ng-model="switchModel2">' +
            '</switch>',
            customEl3 = '<switch ' +
            'has-icon="true"' +
            'ng-model="switchModel2">' +
            '</switch>',
            customEl4 = '<switch ' +
            'has-icon="false"' +
            'ng-model="switchModel2">' +
            '</switch>',
            element,
            hasIcon;

        it('should set hasIcon to false when has-icon attribute not present', function() {

            element = compileDirective($scope, customEl);

            $scope.$digest();

            hasIcon = element.isolateScope().switchCtrl.hasIcon;

            expect(hasIcon).toEqual(false);

        });

        it('should set hasIcon to true when has-icon attribute present', function() {

            element = compileDirective($scope, customEl2);

            $scope.$digest();

            hasIcon = element.isolateScope().switchCtrl.hasIcon;

            expect(hasIcon).toEqual(true);

        });

        it('should set hasIcon to true when has-icon attribute set to true', function() {

            element = compileDirective($scope, customEl3);

            $scope.$digest();

            hasIcon = element.isolateScope().switchCtrl.hasIcon;

            expect(hasIcon).toEqual(true);

        });

        it('should set hasIcon to false when has-icon attribute set to false', function() {

            element = compileDirective($scope, customEl4);

            $scope.$digest();

            hasIcon = element.isolateScope().switchCtrl.hasIcon;

            expect(hasIcon).toEqual(false);

        });

    });

    describe('Important switch', function() {

        var customEl = '<switch ' +
            'ng-model="switchModel2">' +
            '</switch>',
            customEl2 = '<switch ' +
            'is-important ' +
            'ng-model="switchModel2">' +
            '</switch>',
            customEl3 = '<switch ' +
            'is-important="true"' +
            'ng-model="switchModel2">' +
            '</switch>',
            customEl4 = '<switch ' +
            'is-important="false"' +
            'ng-model="switchModel2">' +
            '</switch>',
            element,
            isImportant;

        it('should set isImportant to false when is-important attribute not present', function() {

            element = compileDirective($scope, customEl);

            $scope.$digest();

            isImportant = element.isolateScope().switchCtrl.isImportant;

            expect(isImportant).toEqual(false);

        });

        it('should set isImportant to true when is-important attribute present', function() {

            element = compileDirective($scope, customEl2);

            $scope.$digest();

            isImportant = element.isolateScope().switchCtrl.isImportant;

            expect(isImportant).toEqual(true);

        });

        it('should set isImportant to true when is-important attribute set to true', function() {

            element = compileDirective($scope, customEl3);

            $scope.$digest();

            isImportant = element.isolateScope().switchCtrl.isImportant;

            expect(isImportant).toEqual(true);

        });

        it('should set isImportant to false when is-important attribute set to false', function() {

            element = compileDirective($scope, customEl4);

            $scope.$digest();

            isImportant = element.isolateScope().switchCtrl.isImportant;

            expect(isImportant).toEqual(false);

        });

    });
});
