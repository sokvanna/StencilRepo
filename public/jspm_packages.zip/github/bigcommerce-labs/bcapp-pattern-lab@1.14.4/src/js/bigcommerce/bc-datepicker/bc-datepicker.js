/* */ 
angular.module('bcapp-pattern-lab.bc-datepicker', [
    'bcapp-pattern-lab.bc-datepicker.directive'
]);
