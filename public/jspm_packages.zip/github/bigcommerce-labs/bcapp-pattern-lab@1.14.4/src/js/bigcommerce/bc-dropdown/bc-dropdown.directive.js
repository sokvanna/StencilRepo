/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown.directive', [])
    .directive('bcDropdown', function bcDropdownDirective() {
        return {
            restrict: 'EA',
            controller: function bcDropdownDirectiveController() {
                var ctrl = this,
                    uniqueId;

                ctrl.getUniqueId = getUniqueId;

                function getUniqueId() {
                    if (!uniqueId) {
                        uniqueId = _.uniqueId('bc-dropdown-');
                    }
                    return uniqueId;
                }
            }
        };
    });
