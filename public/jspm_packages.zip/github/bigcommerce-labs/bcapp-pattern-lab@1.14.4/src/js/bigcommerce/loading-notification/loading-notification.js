/* */ 
angular.module('bcapp-pattern-lab.loading-notification', [
    'bcapp-pattern-lab.loading-notification.directive'
]);
