/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown-menu.directive', [])
    .directive('bcDropdownMenu', function bcDropdownMenuDirective() {
        return {
            restrict: 'A',
            require: '^bcDropdown',
            compile: function bcDropdownMenuDirectiveCompile(tElement) {
                tElement.addClass('dropdown-menu');

                return function bcDropdownMenuDirectiveLink(scope, element, attrs, bcDropdownCtrl) {
                    element.attr('id', bcDropdownCtrl.getUniqueId());
                };
            }
        };
    });
