/* */ 
angular.module('bcapp-pattern-lab.bc-server-table.directive', [
    'bcapp-pattern-lab.bc-server-table.controller',
    'bcapp-pattern-lab.bc-server-table.sort-by.directive',
    'ui.router'
])
    /**
     * The bc-server-table directive creates a data table that handles
     * server side pagination, sorting, and filtering. It exposes a few scope variables,
     * that can be used to display the table content with custom markup (see example
     * in the pattern lab for an actual implementation of the bc-server-table).
     *
     * The following attributes can be passed in order to configure the bc-server-table:
     * - resource-callback (required)
     * - tableConfig (optional)
     *
     * - resource-callback - a function that returns a promise which is resovled
     * with an object of the following format:
     *      {
     *          rows: Array,
     *          pagination: {
     *              page: Number,
     *              limit: Number,
     *              total: Number
     *          }
     *      }
     *
     * This directive exposes a scope variable called bcServerTable that
     * can be used to display content, and implement additional functionality
     * to the table (such as pagination, sorting, and selection logic).
     *
     * - bcServerTable.rows
     *      - Can be used with ng-repeat to display the data
     * - bcServerTable.filters
     *      - Can be used to change/update filters. These filters must appear
     *        in the state definition in order to work correctly.
     * - bcServerTable.updateTable()
     *      - Perform a state transistion with the current table info
     * - bcServerTable.pagination
     *      - exposes page, limit, and total
     * - bcServerTable.setPaginationValues(pagination)
     *      - convenience method for setting pagination values at once.
     *
     * - bcServerTable.selectedRows
     *      - an map object with unique id's as keys and boolean values as the selected state
     * - bcServerTable.allSelected
     *      - a boolean value used to determine if all rows were selected or cleared
     * - bcServerTable.selectAllRows()
     *      - toggle all rows selection state
     * - bcServerTable.isRowSelected(row)
     *      - helper function to determine if a row is selected
     * - bcServerTable.getSelectedRows()
     *      - function that returns an array of row objects that are currently selected
     *
     */
    .directive('bcServerTable', function bcServerTableDirective($parse) {
        var directive = {
            restrict: 'EA',
            controller: 'BcServerTableCtrl as bcServerTable',
            link: function bcServerTableLink($scope, element, attrs, bcServerTableCtrl) {
                if (attrs.tableController) {
                    // expose bcServerTableCtrl to tableController if it exists
                    $parse(attrs.tableController).assign($scope, bcServerTableCtrl);
                }
            }
        };

        return directive;
    });
