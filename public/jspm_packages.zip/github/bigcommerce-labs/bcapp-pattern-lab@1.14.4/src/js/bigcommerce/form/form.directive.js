/* */ 
angular.module('bcapp-pattern-lab.form.directive', [])
    .directive('form', function formDirective() {
        return {
            restrict: 'E',
            link: function formLink(scope, element, attrs) {
                element.addClass('form');
                element.attr('novalidate', '');

                // Use disable-auto-focus="true" to turn off automatic error focusing
                if (!attrs.disableAutoFocus) {
                    element.on('submit', function formAutoFocusSubmitHandler() {
                        var invalidField = element[0].querySelector('.ng-invalid');

                        if (invalidField) {
                            invalidField.focus();

                            // Auto-select existing text for fields that support it (text, email, password, etc.)
                            if (invalidField.select) {
                                invalidField.select();
                            }
                        }
                    });
                }
            }
        };
    });
