/* */ 
describe('Directive: bcPagination', function () {
    var $compile,
        $scope,
        mockClickEvent;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.bc-pagination'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
        mockClickEvent = $scope.$broadcast('click');
    }));

    function compileDirective(scope, ignoreDefaults, onChangeExpression) {
        var onChange = onChangeExpression || 'onChange';

        if (!ignoreDefaults) {
            scope.totalItems = scope.totalItems || 100;
            scope.page = scope.page || 1;
            scope.itemsPerPage = scope.itemsPerPage || 10;
            scope.limits = scope.limits || [10, 20, 50];
            scope.onChange = scope.onChange || angular.noop;
            scope.showLimits = scope.showLimits === undefined ? true : scope.showLimits;
        }

        var element = angular.element('<bc-pagination ' +
            'total-items="totalItems"' +
            'page="page"' +
            'items-per-page="itemsPerPage"' +
            'limits="limits"' +
            'show-limits="showLimits"' +
            'on-change="' + onChange + '"></bc-pagination>');

        return $compile(element)(scope);
    }

    describe('setLimit function', function() {
        it('should set the limit', function() {
            var element = compileDirective($scope);

            $scope.$digest();

            element.scope().setLimit(10, mockClickEvent);
            expect($scope.itemsPerPage).toBe(10);
            element.scope().setLimit(20, mockClickEvent);
            expect($scope.itemsPerPage).toBe(20);
        });

        it('should change the current page to 1 when limits are changed', function() {
            var element;

            $scope.page = 2;
            element = compileDirective($scope);
            $scope.$digest();

            expect($scope.page).toBe(2);
            element.scope().setLimit(20, mockClickEvent);
            expect($scope.page).toBe(1);
        });
    });

    describe('getCurrentPage function', function() {
        it('should return the current pagination page', function() {
            var element;

            $scope.page = 2;
            element = compileDirective($scope);
            $scope.$digest();

            expect(element.scope().getCurrentPage()).toBe(2);
            $scope.page = 1;
            expect(element.scope().getCurrentPage()).toBe(1);
        });
    });

    describe('getCurrentLimit function', function() {
        it('should return the current limit', function() {
            var element;

            $scope.itemsPerPage = 5;
            element = compileDirective($scope);
            $scope.$digest();

            expect(element.scope().getCurrentLimit()).toBe(5);
            $scope.itemsPerPage = 10;
            expect(element.scope().getCurrentLimit()).toBe(10);

        });
    });

    describe('getLimits function', function() {
        it('should return the limits', function() {
            var element;

            $scope.limits = [10, 100];
            element = compileDirective($scope);
            $scope.$digest();

            expect(element.scope().getLimits()).toEqual([10, 100]);
            $scope.limits = [10, 200];
            expect(element.scope().getLimits()).toEqual([10, 200]);
        });
    });

    describe('callback function', function() {
        function callbackTestHelper($scope) {
            var element;

            $scope.testFunc = angular.noop;

            if (!$scope.onChange) {
                $scope.onChange = function(changes) {
                    $scope.testFunc(changes);
                };
            }

            spyOn($scope, 'testFunc');
            element = compileDirective($scope);
            $scope.$digest();

            return element;
        }

        it('should be called', function() {
            var element;

            $scope.page = 5;
            $scope.itemsPerPage = 20;

            element = callbackTestHelper($scope);

            element.scope().paginationCallback();
            expect($scope.testFunc).toHaveBeenCalled();
        });

        it('should call the expression with the right context', function() {
            $scope.obj = {
                onChangeFunc: function onChangeFunc() {
                    this.value = true;
                },
                value: false
            };

            element = compileDirective($scope, false, 'obj.onChangeFunc()');
            $scope.$digest();
            element.scope().paginationCallback();
            expect($scope.obj.value).toBe(true);
        });

        it('should be called when limits change', function() {
            var element;

            $scope.itemsPerPage = 10;

            element = callbackTestHelper($scope);

            element.scope().setLimit(5, mockClickEvent);
            expect($scope.testFunc).toHaveBeenCalled();
        });

        it('should be called when an object with page and limit', function() {
            var element;

            $scope.itemsPerPage = 10;

            element = callbackTestHelper($scope);

            element.scope().setLimit(5, mockClickEvent);
            expect($scope.testFunc).toHaveBeenCalledWith({ page: 1, limit: 5 });
        });
    });

    describe('show function', function() {
        var element;

        beforeEach(function() {
            element = compileDirective($scope);
        });

        it('should return true if there is more than one page', function() {
            $scope.$digest();
 
            expect(element.scope().show()).toBeTruthy();
        });
 
        it('should return false if there is one page or less', function() {
            $scope.totalItems = 1;
            $scope.$digest();

            expect(element.scope().show()).toBeFalsy();
        });
    });

    describe('showLimits function', function() {
        var element;

        beforeEach(function() {
            element = compileDirective($scope);
        });

        describe('if pagination is visible', function() {
            it('should return true if showLimits is true', function() {
                $scope.$digest();
                spyOn(element.scope(), 'show').and.returnValue(true);

                expect(element.scope().showLimits()).toBeTruthy();
            });

            it('should return false if showLimits is false', function() {
                $scope.showLimits = false;
                $scope.$digest();
                spyOn(element.scope(), 'show').and.returnValue(true);

                expect(element.scope().showLimits()).toBeFalsy();
            });
        });

        describe('if pagination is not visible', function() {
            it('should return false', function() {
                $scope.$digest();
                spyOn(element.scope(), 'show').and.returnValue(false);

                expect(element.scope().showLimits()).toBeFalsy();
            });
        });
    });
});
