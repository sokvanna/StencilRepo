/* */ 
angular.module('bcapp-pattern-lab.bc-server-table-factory.service', [
    'bcapp-pattern-lab.bc-server-table.service'
])
    .factory('bcServerTableFactory', function bcServerTableFactory($log, BcServerTable) {
        var tables = {},
            service = {
                create: create,
                get: get,
                remove: remove
            };

        function create(tableId, tableConfig) {
            if (tableId in tables) {
                return service.get(tableId);
            }

            if (!tableId) {
                tableId = _.uniqueId('bc-server-table-instance-');
            }

            tables[tableId] = new BcServerTable(tableId, tableConfig);

            return tables[tableId];
        }

        function get(tableId) {
            return tables[tableId];
        }

        function remove(tableId) {
            delete tables[tableId];
        }

        return service;
    });
