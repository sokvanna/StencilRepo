/* */ 
angular.module('bcapp-pattern-lab.credit-card.cc-expiry', [
    'bcapp-pattern-lab.credit-card.cc-expiry.directive',
]);
