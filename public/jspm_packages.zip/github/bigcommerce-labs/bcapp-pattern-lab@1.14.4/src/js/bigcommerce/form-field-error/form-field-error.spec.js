/* */ 
describe('form-field-error directive', function() {
    var $compile,
        $rootScope,
        element,
        formCtrl,
        formFieldErrorElements;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.form-field'));
    beforeEach(module('bcapp-pattern-lab.form-field-error'));
    beforeEach(module('bcapp-pattern-lab.form-field-errors'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {
        var tpl = angular.element(
            '<form>' +
                '<form-field property="username">' +
                '   <input name="username" ng-model="username" type="email" required />' +
                    '<form-field-errors>' +
                        '<form-field-error validate="email">{{ email }}</form-field-error>' +
                        '<form-field-error validate="required">{{ required }}</form-field-error>' +
                    '</form-field-errors>' +
                '</form-field>' +
                '<button type="submit">Submit</button>' +
            '</form>'
        );

        scope = scope || $rootScope.$new();
        scope.email = 'Username must be an email address';
        scope.required = 'Username is required';
        element = $compile(tpl)(scope);

        scope.$digest();

        formCtrl = element.controller('form');
        formFieldErrorElements = element.find('li');

        return scope;
    }

    describe('error elements', function() {
        beforeEach(function() {
            compileDirective();
        });

        it('should include the standard class', function() {
            _.each(formFieldErrorElements, function(errorElement) {
                expect(angular.element(errorElement).hasClass('form-field-error')).toBeTruthy();
            });
        });

        it('should add all required attributes to the internal label', function() {
            _.each(formFieldErrorElements, function(errorElement) {
                var label = angular.element(errorElement).find('label');

                expect(label.attr('for')).toBeTruthy();
                expect(label.attr('ng-message')).toBeTruthy();
                expect(label.hasClass('form-inlineMessage')).toBe(true);
            });
        });

        it('should display the injected error message', function() {
            var scope = compileDirective();

            _.each(formFieldErrorElements, function(errorElement) {
                var label = angular.element(errorElement).find('label'),
                    validator = angular.element(errorElement).attr('validate'),
                    validatorMessage = scope[validator];

                expect(label.html()).toContain(validatorMessage);
            });
        });
    });

    describe('scope', function() {
        it('should have all the required properties set', function() {
            var scope;

            compileDirective();

            scope = formFieldErrorElements.scope();

            expect(scope.property).toEqual('username');
        });
    });
});
