/* */ 
angular.module('bcapp-pattern-lab.bc-pagination.directive', [])
    .directive('bcPagination', function bcPaginationDirective($parse) {
        return {
            restrict: 'E',
            scope: true,
            templateUrl: 'src/js/bigcommerce/bc-pagination/bc-pagination.tpl.html',

            compile: function bcPaginationCompile(tElement, tAttrs) {
                var attrObj = {};

                // Since this is a wrapper of angular-foundation's pagination directive we need to copy all
                // of the attributes passed to our directive and store them in the attrObj.
                _.each(tAttrs.$attr, function(key) {
                    if (key !== 'class') {
                        attrObj[key] = tElement.attr(key);
                    }
                });

                // Adding our custom callback to the attrObj, angular-foundation will call this function
                // when a page number is clicked in the pagination.
                attrObj['on-select-page'] = 'paginationCallback(page)';

                // Add all the attributes to angular-foundation's pagination directive
                tElement.find('pagination').attr(attrObj);

                return function bcPaginationLink($scope, element, attrs) {
                    var onChangeParseGetter = $parse(attrs.onChange),
                        defaultLimits = [10, 20, 30, 50, 100];

                    $scope.setLimit = function(limit, event) {
                        event.preventDefault();
                        limit = _.parseInt(limit);
                        $parse(attrs.itemsPerPage).assign($scope.$parent, limit);
                        $scope.paginationCallback(1, limit);
                    };

                    $scope.getCurrentPage = function() {
                        return $parse(attrs.page)($scope.$parent);
                    };

                    $scope.getCurrentLimit = function() {
                        return $parse(attrs.itemsPerPage)($scope.$parent);
                    };

                    $scope.getItemsPerPage = function() {
                        return $parse(attrs.itemsPerPage)($scope.$parent) || 0;
                    };

                    $scope.getTotalItems = function() {
                        return $parse(attrs.totalItems)($scope.$parent) || 0;
                    };

                    $scope.show = function() {
                        return $scope.getTotalItems() > $scope.getItemsPerPage();
                    };

                    $scope.showLimits = function() {
                        return $scope.show() && $parse(attrs.showLimits)($scope.$parent) !== false;
                    };

                    $scope.getLimits = function() {
                        var limits = $parse(attrs.limits)($scope.$parent);

                        if (!Array.isArray(limits)) {
                            return defaultLimits;
                        }

                        return limits;
                    };

                    $scope.paginationCallback = function(page, limit) {
                        var additionalScopeProperties = {
                                limit: limit || $scope.getCurrentLimit(),
                                page: page
                            },
                            onChangeParseResult;

                        $parse(attrs.page).assign($scope.$parent, page);

                        onChangeParseResult = onChangeParseGetter($scope, additionalScopeProperties);

                        // if the onChange string is a function and not an expression: call it with the additionalScopeProperties obj (for backwards compatability)
                        // else the expression has already been ran: do nothing
                        if (typeof onChangeParseResult === 'function') {
                            onChangeParseResult(additionalScopeProperties);
                        }
                    };
                };
            }
        };
    });
