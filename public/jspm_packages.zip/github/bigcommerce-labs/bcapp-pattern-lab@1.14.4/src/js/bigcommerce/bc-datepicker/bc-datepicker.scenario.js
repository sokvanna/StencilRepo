/* */ 
describe('bc-datepicker', function() {
    beforeEach(function() {
        browser.get('/js-components.html#/components/bc-datepicker');
    });

    it('should be hidden by default', function() {
        expect($('.datepicker-attachment').getCssValue('display')).toBe('none');
    });

    it('should display when the input box is clicked', function() {
        $('input').click();
        expect($('.datepicker-attachment').getCssValue('display')).not.toBe('none');
    });

    it('should display the date typed', function() {
        $('input').sendKeys('01/01/2015');
        expect($('.selected-date').getText()).toBe('01/01/2015');
    });

    it('should go to the previous month when the previous arrow is clicked', function() {
        $('input').sendKeys('01/01/2015');
        expect($('.selected-date').getText()).toBe('01/01/2015');

        $('.datepicker-attachment .datepicker-back').click();
        expect($('.selected-date').getText()).toBe('12/01/2014');
    });

    it('should go to the next month when the next arrow is clicked', function() {
        $('input').sendKeys('01/01/2015');
        expect($('.selected-date').getText()).toBe('01/01/2015');

        $('.datepicker-attachment .datepicker-next').click();
        expect($('.selected-date').getText()).toBe('02/01/2015');
    });

    it('should select a day when clicekd', function() {
        $('input').sendKeys('01/01/2015');
        $$('.datepicker-attachment .datepicker-day').first().click();

        expect($('.selected-date').getText()).toBe('12/28/2014');
    });
});
