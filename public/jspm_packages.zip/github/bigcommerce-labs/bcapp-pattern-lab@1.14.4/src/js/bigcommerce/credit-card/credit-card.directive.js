/**
 * @name credit-card directive
 * @description Component containing cc number, cvc, name, and expiry. Has an isolated scope with no controller.
 * @require form
 *
 * @param ccData {object} Contains ccNumber, ccType, ccExpiry, and ccName
 * @param ccConfig {object} The configuration object. Currently supporting `cardCode` and `fullName`, both boolean to indicate
 * whether the respective fields should be shown. Another field `cardCodeRequired` determines whether the cvc field is required.
 * This only matters when cardCode is set to true.
 */
angular.module('bcapp-pattern-lab.credit-card.directive', [
    'bcapp-pattern-lab.icon'
])
    .directive('creditCard', function creditCardDirective($compile, $templateCache) {
        const cvvTooltipTemplate = $templateCache.get('src/js/bigcommerce/credit-card/credit-card-cvv/tooltip.tpl.html');

        return {
            link: function creditCardLink(scope, elem, attr, formCtrl) {
                const cvvTooltipElement = $compile(cvvTooltipTemplate)(scope);
                const defaultConfig = {
                    cardCode: true,
                    cardCodeRequired: true,
                    fullName: true,
                };

                scope.ccConfig = _.defaults(scope.ccConfig, defaultConfig);
                scope.getCvvTooltipHtml = getCvvTooltipHtml;

                /**
                 * Return the html for the tooltip. Using outerHTML to also include the root element
                 * @return {String} Html string for the cvv tooltip template
                 */
                function getCvvTooltipHtml() {
                    return cvvTooltipElement[0].outerHTML;
                }

                /**
                 * The credit card type is deduced by the `ccNumber` directive. This is in turn exposed
                 * as `$ccEagerType` on the input control element. Watch for changes and bind the type to the corresponding
                 * value on ccData.
                 */
                scope.$watch(getCcType, setCcType);

                scope.formCtrl = formCtrl;

                function getCcType() {
                    return formCtrl.ccNumber.$ccEagerType;
                }

                function setCcType(type) {
                    scope.ccData.ccType = type;
                }
            },
            require: '^form',
            restrict: 'EA',
            scope: {
                ccData: '=',
                ccConfig: '=',
            },
            templateUrl: 'src/js/bigcommerce/credit-card/credit-card.tpl.html'
        };
    });
