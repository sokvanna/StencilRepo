export default class PreviewControls {
    constructor() {
        this.flipped = false;
        this.size = 'desktop';
    }

    canFlip(size) {
        return size === 'mobile' || size === 'tablet';
    }

    flip() {
        this.flipped = !this.flipped;
    }

    getSize() {
        return this.size;
    }

    isFlipped() {
        return this.flipped;
    }

    setSize(sizeToSet) {
        this.size = sizeToSet;

        return this.getSize();
    }
}
