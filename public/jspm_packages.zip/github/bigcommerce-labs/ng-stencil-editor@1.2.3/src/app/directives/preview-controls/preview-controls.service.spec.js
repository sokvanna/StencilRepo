import 'angular';
import 'angular-mocks';
import PreviewControls from './preview-controls.service.js';

describe('Theme preview controls service', () => {
    let previewControlsService = new PreviewControls();

    describe('set up', () => {

        it('should start unflipped', () => {
            expect(previewControlsService.flipped).toBe(false);
        });

        it('should start as desktop', () => {
            expect(previewControlsService.size).toBe('desktop');
        });

    });

    describe('getters', () => {

        it('should not allow desktop to flip', () => {
            expect(previewControlsService.canFlip('desktop')).toBe(false);
        });

        it('should allow mobile to flip', () => {
            expect(previewControlsService.canFlip('mobile')).toBe(true);
        });

        it('should allow tablet to flip', () => {
            expect(previewControlsService.canFlip('tablet')).toBe(true);
        });

        it('should return flipped state', () => {
            expect(previewControlsService.isFlipped()).toBe(false);
        });

        it('should return current size', () => {
            expect(previewControlsService.getSize()).toBe('desktop');
        });

    });

    describe('setters', () => {

        it('should flip preview', () => {
            previewControlsService.flip();
            expect(previewControlsService.isFlipped()).toBe(true);
        });

        it('should set new size', () => {
            expect(previewControlsService.setSize('tablet')).toBe('tablet');
        });

    });
});
