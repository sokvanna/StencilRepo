export default class {
    /*@ngInject*/
    constructor (channelService) {
        this.createChannel = channelService.createChannel.bind(channelService);
    }
}
