import ThemeInfoModalCtrl from 'src/app/modals/theme-info-modal/theme-info-modal.controller.js';

export default class {
    /*@ngInject*/
    constructor($modal) {
        this._$modal = $modal;
    }

    info($event) {
        $event.preventDefault();

        this._$modal.open({
            controller: ThemeInfoModalCtrl,
            controllerAs: 'themeInfoModalCtrl',
            templateUrl: 'app/modals/theme-info-modal/theme-info-modal.tpl.html',
            windowClass: 'modal--small'
        });
    }
}
