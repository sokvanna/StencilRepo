import ThemeRelayCtrl from 'src/app/directives/theme-relay/theme-relay.controller.js';

class ThemeRelay {
    constructor() {
        this.bindToController = true;
        this.controller = ThemeRelayCtrl;
        this.controllerAs = 'themeRelayCtrl';
        this.restrict = 'A';
        this.scope = {
            themeRelay: '='
        };
    }

    link(scope, element, attrs, themeRelayCtrl) {
        themeRelayCtrl.createChannel({
            window: element[0].contentWindow,
            origin: '*',
            scope: 'stencilEditor',
            reconnect: true
        });
    }

    /** @ngInject */
    static directiveFactory() {
        return new ThemeRelay();
    }
}

ThemeRelay.directiveFactory.$inject = [];

export default ThemeRelay.directiveFactory;
