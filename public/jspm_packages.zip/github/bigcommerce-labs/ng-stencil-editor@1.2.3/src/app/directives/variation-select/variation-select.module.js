import variationSelectDirective from 'src/app/directives/variation-select/variation-select.directive.js';

export default angular.module('ng-stencil-editor.directives.variation-select', [])
    .directive('variationSelect', variationSelectDirective);
