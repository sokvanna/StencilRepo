import VariationSelectCtrl from 'src/app/directives/variation-select/variation-select.controller.js';

class VariationSelect {
    constructor() {
        this.bindToController = true;
        this.controller = VariationSelectCtrl;
        this.controllerAs = 'variationSelectCtrl';
        this.restrict = 'AE';
        this.scope = {
            editorForm: '=',
            variationChange: '&',
            variationChanging: '&'
        };
        this.templateUrl = 'app/directives/variation-select/variation-select.tpl.html';
    }

    /** @ngInject */
    static directiveFactory() {
        return new VariationSelect();
    }
}

VariationSelect.directiveFactory.$inject = [];

export default VariationSelect.directiveFactory;
