export default class SessionService {
    /*@ngInject*/
    constructor($http, $q, BC_SEED_DATA) {
        this._$http = $http;
        this._$q = $q;
        this._BC_SEED_DATA = BC_SEED_DATA;
    }

    heartbeat() {
        const baseUrl = this._BC_SEED_DATA.oauthBaseUrl;

        if (baseUrl) {
            return this._$http.jsonp(baseUrl + '/session/heartbeat?callback=JSON_CALLBACK')
                .then(resp => resp.data);
        } else {
            return this._$q.when({ ok: true });
        }
    }
}
