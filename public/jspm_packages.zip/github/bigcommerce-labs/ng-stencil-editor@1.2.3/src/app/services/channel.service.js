export default class ChannelService {
    /*@ngInject*/
    constructor($window) {
        this._$window = $window;
        this._channel = null;
    }

    createChannel(options) {
        this._channel = this._$window.Channel.build(options);
    }

    emit(name, options = {}) {
        if (this._channel) {
            this._channel.call({
                method: name,
                params: JSON.stringify(options.data || {}),
                success: options.success || angular.noop,
                error: options.error || angular.noop
            });
        }
    }
}
