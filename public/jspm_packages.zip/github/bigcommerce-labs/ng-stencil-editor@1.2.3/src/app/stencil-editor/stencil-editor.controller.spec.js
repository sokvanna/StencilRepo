import 'angular';
import 'angular-mocks';

import StencilEditorController from './stencil-editor.controller.js';

describe('StencilEditorCtrl: ', () =>  {
    let $controller;
    let $q;
    let $rootScope;
    let controller;
    let configService = jasmine.createSpyObj('configService', [
        'clear',
        'findChanges',
        'getConfig',
        'hasChanges',
        'isLoading',
        'preview',
        'publish',
        'reset',
        'save',
    ]);
    let fontsService = jasmine.createSpyObj('fontsService', [
        'addFont',
        'setInitialFonts',
    ]);
    let channelService = jasmine.createSpyObj('channelService', [
        'createChannel',
        'emit',
    ]);
    let versionService = jasmine.createSpyObj('versionService', [
        'getFieldsets',
        'getVersion'
    ]);
    let variationService = jasmine.createSpyObj('variationService', [
        'activeVariation',
        'getActiveVariation',
        'getVariations',
    ]);
    let $modal = jasmine.createSpyObj('$modal', [
        'open',
    ]);

    function createController(isProduction) {
        return $controller(StencilEditorController, {
            $modal: $modal,
            $q: $q,
            BC_APP_CONFIG: { isProduction: !!isProduction },
            channelService: channelService,
            configService: configService,
            fontsService: fontsService,
            versionService: versionService,
            variationService: variationService
        });
    }

    beforeEach(inject(($injector) => {
        $controller = $injector.get('$controller');
        $q = $injector.get('$q');
        $rootScope = $injector.get('$rootScope');

        configService.getConfig.and.returnValue({ id: 1 });
    }));

    describe('apply() method', () => {
        let modalDeferred;

        beforeEach(() => {
            modalDeferred = $q.defer();
            $modal.open.and.returnValue({ result: modalDeferred.promise });
        });

        it('should open a modal', () => {
            controller = createController();
            spyOn(controller, 'init');

            controller.apply();

            expect($modal.open).toHaveBeenCalled();
        });

        it('should call configService.publish() with the current config', () => {
            configService.publish.and.returnValue($q.when());

            controller = createController();

            controller.apply();
            modalDeferred.resolve();
            $rootScope.$apply();

            expect(configService.publish).toHaveBeenCalledWith(controller.config);
        });

        it('should call resetForm if the publish was successful', () => {
            configService.publish.and.returnValue($q.when());

            controller = createController();
            spyOn(controller, 'resetForm');

            controller.apply();
            modalDeferred.resolve();
            $rootScope.$apply();

            expect(controller.resetForm).toHaveBeenCalled();
        });

        it('should call openErrorModal and pass an error if publish fails', () => {
            const testError = { error: 'Test Error' };

            configService.publish.and.returnValue($q.reject(testError));

            controller = createController();
            spyOn(controller, 'openErrorModal');

            controller.apply();
            modalDeferred.resolve();
            $rootScope.$apply();

            expect(controller.openErrorModal).toHaveBeenCalledWith(testError);
        });
    });

    describe('clear() method', () => {
        it('should call configService.clear(), resetForm(), emit reload-styles, and then configService.preview()', () => {
            const clearDeferred = $q.defer();
            const modalDeferred = $q.defer();
            const previewDeferred = $q.defer();
            const mockConfig = { id: 1 };

            controller = createController();
            spyOn(controller, 'resetForm');

            $modal.open.and.returnValue({ result: modalDeferred.promise });
            configService.clear.and.returnValue(clearDeferred.promise);
            configService.preview.and.returnValue(previewDeferred.promise);

            controller.clear();

            expect($modal.open).toHaveBeenCalled();

            modalDeferred.resolve();
            clearDeferred.resolve(mockConfig);
            previewDeferred.resolve(mockConfig);

            $rootScope.$apply();

            expect(configService.clear).toHaveBeenCalled();
            expect(channelService.emit).toHaveBeenCalledWith('reload-stylesheets', jasmine.any(Object));
            expect(controller.resetForm).toHaveBeenCalled();
        });
    });

    describe('submit() method', () => {
        beforeEach(() => {
            configService.save.and.returnValue({
                then: (cb) => { cb(); }
            });
        });

        it('should call configService.save', () => {
            controller = createController();

            controller.submit();

            expect(configService.save).toHaveBeenCalled();
        });

        it('should call resetForm when configService.save resolves', () => {
            controller = createController();

            spyOn(controller, 'resetForm');

            controller.submit();

            expect(controller.resetForm).toHaveBeenCalled();
        });
    });

    describe('resetVariant() method', () => {
        const defaultVariant = { defaultConfigurationId: 123 };

        let modalDeferred;
        let resetDeferred;

        beforeEach(() => {
            modalDeferred = $q.defer();
            resetDeferred = $q.defer();

            variationService.activeVariation.and.returnValue(defaultVariant);
            configService.reset.and.returnValue(resetDeferred.promise);

            $modal.open.and.returnValue({ result: modalDeferred.promise });
        });

        it('should open a modal', () => {
            controller = createController();
            spyOn(controller, 'init');

            controller.resetVariant();

            expect($modal.open).toHaveBeenCalled();
        });

        it('should call configService reset with the defaultConfigurationId', () => {
            controller = createController();

            controller.resetVariant();

            modalDeferred.resolve();
            resetDeferred.resolve();

            $rootScope.$apply();

            expect(configService.reset).toHaveBeenCalledWith(defaultVariant);
        });

        it('should call openErrorModal if there was an error', () => {
            controller = createController();

            spyOn(controller, 'openErrorModal');

            controller.resetVariant();

            modalDeferred.resolve();
            resetDeferred.reject();

            $rootScope.$apply();

            expect(controller.openErrorModal).toHaveBeenCalled();
        });
    });
});
