import './templates.js';
import appApi from './app.api.js';
import appConfig from './app.config.js';
import appRun from './app.run.js';

import stencilEditorModule from './stencil-editor/stencil-editor.module.js';
import servicesModule from './services/services.module.js';
import directivesModule from './directives/directives.module.js';

export default angular
    .module('ng-stencil-editor', [
        //app dependencies
        'ng-common',
        'bcapp-pattern-lab',
        'ng-stencil-editor.templates',

        //third-party dependencies
        'formly',
        'gettext',
        'ui.router',
        'ngCookies',

        //child modules
        stencilEditorModule.name,

        //directives
        directivesModule.name,

        //services
        servicesModule.name,

        //constants
        appApi.name
    ])
    .config(appConfig)
    .run(appRun);
