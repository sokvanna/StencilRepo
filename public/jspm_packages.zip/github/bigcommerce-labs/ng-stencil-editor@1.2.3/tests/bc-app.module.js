import 'angular';
import 'angular-mocks';

angular.module('ng-common.bc-app', [])
    .constant('BC_APP_CONFIG', {})
    .constant('BC_SEED_DATA', {});
