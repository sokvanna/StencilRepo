import editorSchema from './schema.mock.js';

export default {
    id: 'theme',
    name: 'Stencil',
    price: 0,
    displayVersion: '1.0.1',
    editorSchema: editorSchema,
    status: 'draft',
    numVariations: 3,
    defaultVariationId: '1',
    screenshot: 'mockScreenshotUrl'
};
