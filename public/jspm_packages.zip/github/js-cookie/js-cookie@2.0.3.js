define(["github:js-cookie/js-cookie@2.0.3/src/js.cookie"], function(main) {
  return main;
});