/* */ 
"format cjs";
module.exports = require("./lib/babel/polyfill");
